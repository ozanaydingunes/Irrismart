package com.irrismart.ai.dev;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
