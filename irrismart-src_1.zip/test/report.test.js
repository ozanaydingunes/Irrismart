// Excel raporu: sayısal değerler gerçek sayı hücresi olarak kaydedilir
const XLSX = require('xlsx');
const { E, W, test, near, ok } = require('./_lib');
const RD = require(W('report-data.js'));
const proj = { name: 'Test', inp: { crop: 'domates' } };
const inp = { crop: 'domates', area_da: 50, L: 400, W: 125, Q: 45, srcType: 'kuyu', depth: 40, region: 'akdeniz' };

function roundTrip(r) {
  const buf = XLSX.write(RD.workbook(XLSX, proj, r), { bookType: 'xlsx', type: 'buffer' });
  return XLSX.read(buf, { type: 'buffer', cellNF: true });
}

test('Excel: özet ve hidrolik değerleri sayı hücresi, birim ayrı sütunda', () => {
  const r = E.design(inp), wb = roundTrip(r);
  const ws = wb.Sheets['Özet'], rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
  const alanRow = rows.findIndex(x => x[0] === 'Alan');
  const cell = ws[XLSX.utils.encode_cell({ r: alanRow, c: 1 })];
  ok(cell.t === 'n', `Alan hücresi sayı değil (${cell.t})`); near(cell.v, 50, 1e-9, 'alan değeri'); ok(rows[alanRow][2] === 'da', 'birim sütunu');
  ok(/0\.00/.test(cell.z || ''), `sayı biçimi yok: ${cell.z}`);
  const h = wb.Sheets['Hidrolik'], hr = XLSX.utils.sheet_to_json(h, { header: 1 });
  const Hrow = hr.findIndex(x => x[0] === 'Gerekli basma yüksekliği (maks.)');
  ok(h[XLSX.utils.encode_cell({ r: Hrow, c: 1 })].t === 'n', 'H sayı değil');
  near(hr[Hrow][1], r.main.sel.Hmax, 1e-9, 'H değeri tam hassasiyetle');
});

test('Excel: malzeme miktar/fiyat/tutar ve aylık program sayısal; formül hesaplanabilir', () => {
  const r = E.design(inp), wb = roundTrip(r);
  const ws = wb.Sheets['Malzeme (fiyatlı)'], rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
  ok(rows.length > 1, 'fiyatlı kalem yok');
  for (let i = 1; i < rows.length; i++) for (const c of [2, 4, 5]) ok(ws[XLSX.utils.encode_cell({ r: i, c })].t === 'n', `satır ${i} sütun ${c} sayı değil`);
  const sum = rows.slice(1).filter(x => !/opsiyonel/.test(x[1])).reduce((t, x) => t + x[5], 0);
  near(sum, r.cost.subtotal, 1e-6, 'ara toplam');
  const p = wb.Sheets['Aylık program'];
  ok(p['B2'].t === 'n' && p['D2'].t === 'n' && p['G2'].t === 'n', 'aylık program sayısal değil');
});

test('Excel: fiyatsız kalemler ayrı sayfada; eksik fiyatla toplam sayı olarak yazılmaz', () => {
  const r = E.design(inp), wb = roundTrip(r);
  const u = XLSX.utils.sheet_to_json(wb.Sheets['Malzeme (fiyatsız)'], { header: 1 });
  ok(u.length - 1 === r.bom.filter(b => b.fiyat == null).length, 'fiyatsız kalem sayısı');
  const m = XLSX.utils.sheet_to_json(wb.Sheets['Maliyet'], { header: 1 });
  const t = m.find(x => x[0] === 'TOPLAM MALZEME BEDELİ');
  ok(typeof t[1] === 'string' && /Hesaplanmadı/.test(t[1]), 'eksik fiyatla toplam yazıldı');
});
