// IrriSmart AI — rapor tabloları (PDF ve Excel ortak). Değerler SAYI olarak tutulur; birim ayrı sütundadır.
// Satır biçimi: [etiket, değer, birim, ondalık]  — değer sayı veya metin
(function (g) {
  const D = g.IRRI_DATA || (typeof require !== 'undefined' ? require('./data.js') : null);
  const E = () => g.IrriEngine;
  const SRC = { kullanici: 'Kullanıcı', katalog: 'Katalog', ornek: 'Örnek fiyat' };

  function build(p, r) {
    const s = r.schedule, m = r.main.sel, c = D.CROPS[p.inp.crop], sel = r.sel;
    const ozet = [
      ['Proje', p.name, '', null], ['Tarih', new Date().toLocaleDateString('tr-TR'), '', null], ['Bitki', c.ad, '', null],
      ['Tasarım geometrisi', r.field.mode === 'parsel' ? 'Gerçek parsel sınırı' : 'Eşdeğer dikdörtgen', '', null],
      ['Alan', r.field.da, 'da', 2],
      ['Eğim (lateral yönü)', r.field.sLat, '%', 2], ['Eğim (manifold yönü)', r.field.sMan, '%', 2],
      ['Sıra arası', r.field.Sr, 'm', 2], ['Sıra üzeri', r.field.Sp, 'm', 2], ['Bitki sayısı', r.field.plants, 'adet', 0],
      ['Damlatıcı debisi', r.emitter.q, 'l/h', 2], r.emitter.ne ? ['Ağaç başına damlatıcı', r.emitter.ne, 'adet', 0] : ['Damlatıcı aralığı', r.emitter.Se, 'm', 2],
      ['Damlatıcı tipi', r.emitter.pc ? 'Basınç ayarlı (PC)' : 'Normal', '', null],
      ['Sektör sayısı', r.sectors.Ns, 'adet', 0], ['En büyük sektör debisi', r.sectors.Qsec, 'm³/h', 2],
      ['Pompa', r.pump.text, '', null], ['Filtrasyon', r.filter.text, '', null], ['Sektör vanası', `${r.valve.text} × ${r.sectors.Ns}`, '', null],
      r.cost.total != null ? ['Toplam malzeme bedeli', r.cost.total, 'TL', 0] : ['Toplam malzeme bedeli', `Hesaplanmadı — ${r.cost.missing} kalemin fiyatı eksik`, '', null],
    ];
    const hidrolik = [
      ['Lateral çapı', r.lateral.d, 'mm', 0], ['Lateral iç çapı', r.lateral.ic, 'mm', 1],
      ['İzin verilen maks. lateral boyu', r.lateral.Lmax, 'm', 1], ['En uzun lateral', r.lateral.maxLen, 'm', 1],
      ['Lateral adedi', r.lateral.count, 'adet', 0], ['Toplam lateral uzunluğu', r.lateral.len, 'm', 0], ['Kör lateral (damlatıcısız)', r.lateral.lead, 'm', 0],
      ['Damlatıcı adedi', r.lateral.emitters, 'adet', 0],
      ['Maks. lateral basınç farkı', r.lateral.maxDH, 'm', 2], ['Lateral için izin', r.emitter.allowLat, 'm', 2],
      ['Lateral giriş basıncı (maks.)', r.inlet.hLatIn, 'm', 2],
      ['Alt ünite (manifold) adedi', r.manifold.count, 'adet', 0], ['En uzun manifold', r.manifold.LmMax, 'm', 1],
      ['Maks. manifold debisi', r.manifold.Qmax, 'm³/h', 2], ['Maks. manifold hızı', r.manifold.vMax, 'm/s', 2],
      ['Maks. manifold basınç farkı', r.manifold.varMax, 'm', 2], ['Manifold için izin', r.emitter.allowMan, 'm', 2],
      ['Manifold giriş basıncı (maks.)', r.inlet.hManIn, 'm', 2],
      ['Ana hat', `PVC-U Ø${m.od} PN${m.pn}`, '', null], ['Ana hat iç çapı', m.ic, 'mm', 1], ['Ana hat uzunluğu', r.main.Lmain, 'm', 0], ['Kritik yol', r.main.Lcrit, 'm', 0],
      ['Ana hat hızı (en büyük sektör)', m.v, 'm/s', 2], ['Ana hat kaybı (kritik yol)', m.hf, 'm', 2],
      ['Kuyu seviyesi / emme', r.head.depth, 'm', 1], ['Kaynak-arazi kot farkı', r.head.dZ, 'm', 1], ['Arazi içi maks. yükselme', r.head.riseMax, 'm', 2],
      ['Filtre kaybı (kirlenme payı dahil)', r.head.filter, 'm', 2], ['Sektör vanası kaybı', r.head.valve, 'm', 2], ['Gübreleme + sayaç + vanalar', 2, 'm', 1],
      ['Gerekli basma yüksekliği (maks.)', m.Hmax, 'm', 2],
    ];
    if (r.head.Havail > 0) hidrolik.push(['Mevcut şebeke basıncı', r.head.Havail, 'm', 1]);
    const sektor = [['Sektör', 'Alt ünite', 'Debi (m³/h)', 'Gerekli H (m)']].concat(sel.groups.map((gr, j) => [j + 1, gr.length, sel.Qj[j], m.H[j]]));
    const sektorDec = [0, 0, 2, 2];
    const altSek = [['Sektör sayısı', 'En büyük sektör (m³/h)', 'Tur süresi (h)', 'Süreye sığar', 'Ana hat', 'Maks. H (m)', 'Motor (kW)', 'Enerji (kWh/yıl)', 'Karşılaştırma (TL/yıl)', 'Durum']]
      .concat(r.sectorAlts.map(a => [a.Ns, a.Qmax, a.cycleHours, a.feasible ? 'Evet' : 'Hayır', `Ø${a.main.sel.od} PN${a.main.sel.pn}`, a.main.sel.Hmax, a.pump.need ? a.pump.motor : 0, a.kWh, a.missing.length ? 'Fiyat eksik' : a.compare, (a === sel ? 'SEÇİLİ ' : '') + (a.recommended ? 'Önerilen' : '')]));
    const altSekDec = [0, 2, 1, null, null, 1, 1, 0, 0, null];
    const altHat = [['Çap', 'PN', 'Hız (m/s)', 'Kayıp (m)', 'Maks. H (m)', 'Enerji (kWh/yıl)', 'Boru (TL)', 'Enerji (TL/yıl)', 'Yıllık (TL)', 'Not']]
      .concat(r.main.alts.map(a => [a.od, a.pn, a.v, a.hf, a.Hmax, a.kWh, a.pipeCost ?? 'Fiyat yok', a.energyCost, a.annual ?? '—', (a === m ? 'SEÇİLİ ' : '') + a.tags.join(', ')]));
    const altHatDec = [0, 0, 2, 2, 1, 0, 0, 0, 0, null];
    const su = [
      ['Tepe ET0', s.et0, 'mm/gün', 2], ['Kc', s.kc, '', 2], ['Kr', s.Kr, '', 2], ['Net ihtiyaç', s.net, 'mm/gün', 2], ['Brüt ihtiyaç', s.gross, 'mm/gün', 2],
      ['Bitki başına (tepe)', s.lpPlant, 'l/gün', 1], ['Uygulama hızı', s.AR, 'mm/h', 2], ['Kolay alınabilir su (RAW)', s.RAW, 'mm', 1],
      ['Sulama aralığı', s.interval, 'gün', 0], ['Maks. aralık (toprak)', s.Imax, 'gün', 0], ['Sektör başına süre', s.t, 'saat', 2], ['Bir tur süresi', s.cycleHours, 'saat', 1],
      ['Sezonluk su', s.seasonM3, 'm³', 0], ['Sezonluk su (dekar başına)', s.seasonM3 / r.field.da, 'm³/da', 0], ['Sezonluk pompa çalışması', s.pumpHours, 'saat', 0],
      ['Sezonluk enerji', s.kWh, 'kWh', 0], ['Sezonluk enerji bedeli', s.energyCost, 'TL', 0],
    ];
    const prog = [['Ay', 'Kc', 'ET0 (mm/gün)', 'Brüt (mm/gün)', 'Aralık (gün)', 'Süre (saat/sektör)', 'Su (m³/da·ay)']]
      .concat(s.monthly.map(x => [x.ay, x.kc, x.et0, x.gross, x.interval, x.sure, x.m3da]));
    const progDec = [null, 2, 1, 1, 0, 1, 0];
    const bomHead = ['Grup', 'Kalem', 'Miktar', 'Birim', 'Birim fiyat (TL)', 'Tutar (TL)', 'Fiyat kaynağı'];
    const priced = r.bom.filter(b => b.fiyat != null), unpriced = r.bom.filter(b => b.fiyat == null);
    const bomP = [bomHead].concat(priced.map(b => [b.grup, b.kalem + (b.opsiyonel ? ' (opsiyonel)' : ''), b.miktar, b.birim, b.fiyat, b.tutar, SRC[b.kaynak] || '']));
    const bomU = [['Grup', 'Kalem', 'Miktar', 'Birim']].concat(unpriced.map(b => [b.grup, b.kalem + (b.opsiyonel ? ' (opsiyonel)' : ''), b.miktar, b.birim]));
    const bomDec = [null, null, 0, null, 2, 0, null];
    const toplam = [
      ['Fiyatlı kalemler ara toplamı (opsiyoneller hariç)', r.cost.subtotal, 'TL', 0],
      ['Fiyatı eksik zorunlu kalem', r.cost.missing, 'adet', 0], ['Örnek fiyatlı kalem', r.cost.example, 'adet', 0],
      r.cost.total != null ? ['TOPLAM MALZEME BEDELİ', r.cost.total, 'TL', 0] : ['TOPLAM MALZEME BEDELİ', 'Hesaplanmadı (eksik fiyat)', '', null],
    ];
    return { ozet, hidrolik, sektor, sektorDec, altSek, altSekDec, altHat, altHatDec, su, prog, progDec, bomP, bomU, bomDec, toplam };
  }

  // Excel çalışma kitabı (SheetJS). Sayılar gerçek sayı hücresi, ondalık biçimi ayrı.
  function workbook(XLSX, p, r) {
    const T = build(p, r), wb = XLSX.utils.book_new();
    const z = d => d == null ? null : d === 0 ? '#,##0' : '#,##0.' + '0'.repeat(d);
    const sheet = (name, rows, cols, decs) => {
      const ws = XLSX.utils.aoa_to_sheet(rows);
      rows.forEach((row, ri) => row.forEach((v, ci) => {
        if (typeof v !== 'number') return;
        const ref = XLSX.utils.encode_cell({ r: ri, c: ci }), d = decs(ri, ci);
        if (ws[ref] && d != null) ws[ref].z = z(d);
      }));
      ws['!cols'] = cols.map(w => ({ wch: w }));
      XLSX.utils.book_append_sheet(wb, ws, name);
    };
    const kv = (name, rows) => sheet(name, [['Kalem', 'Değer', 'Birim']].concat(rows.map(([a, b, c]) => [a, b, c])), [44, 26, 10], (ri) => ri ? rows[ri - 1][3] : null);
    const tbl = (name, rows, dec, cols) => sheet(name, rows, cols, (ri, ci) => ri ? dec[ci] : null);
    kv('Özet', T.ozet); kv('Hidrolik', T.hidrolik);
    tbl('Sektörler', T.sektor, T.sektorDec, [10, 12, 14, 14]);
    tbl('Sektör alternatifleri', T.altSek, T.altSekDec, [13, 20, 14, 12, 16, 12, 11, 16, 20, 18]);
    tbl('Ana hat alternatifleri', T.altHat, T.altHatDec, [8, 6, 10, 10, 12, 16, 14, 16, 14, 30]);
    kv('Su ihtiyacı', T.su); tbl('Aylık program', T.prog, T.progDec, [8, 8, 14, 14, 12, 18, 16]);
    tbl('Malzeme (fiyatlı)', T.bomP, T.bomDec, [12, 56, 10, 8, 16, 16, 14]);
    tbl('Malzeme (fiyatsız)', T.bomU, T.bomDec, [12, 56, 10, 8]);
    kv('Maliyet', T.toplam);
    sheet('Varsayımlar', [['#', 'Varsayım / uyarı']].concat(r.asm.map((a, i) => [i + 1, a]), r.warn.map(w => ['Uyarı', w])), [7, 110], () => 0);
    return wb;
  }

  g.IrriReportData = { build, workbook };
  if (typeof module !== 'undefined') module.exports = g.IrriReportData;
})(typeof window !== 'undefined' ? window : globalThis);
