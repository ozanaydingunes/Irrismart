// IrriSmart AI — PDF / Excel çıktısı ve dosya kaydetme
(function () {
  const RD = window.IrriReportData;
  const n = (v, d = 1) => (v == null || (typeof v === 'number' && !Number.isFinite(v))) ? '-' : typeof v === 'number' ? v.toLocaleString('tr-TR', { minimumFractionDigits: d, maximumFractionDigits: d }) : String(v);
  const safe = s => String(s).replace(/[^\wçğıöşüÇĞİÖŞÜ\- ]+/g, '').trim().replace(/\s+/g, '_') || 'proje';
  const isNative = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  function b64FromBuf(buf) { let s = ''; const b = new Uint8Array(buf); for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); return btoa(s); }

  async function saveFile(name, base64, mime) {
    if (isNative()) {
      const FS = window.Capacitor.registerPlugin('Filesystem'), Share = window.Capacitor.registerPlugin('Share');
      const w = await FS.writeFile({ path: name, data: base64, directory: 'CACHE' });
      try { await FS.writeFile({ path: 'IrriSmart/' + name, data: base64, directory: 'DOCUMENTS', recursive: true }); } catch (e) { /* bazı Android sürümlerinde izin gerekir */ }
      await Share.share({ title: name, files: [w.uri], dialogTitle: 'Raporu paylaş / kaydet' });
    } else {
      const bin = atob(base64), arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([arr], { type: mime })); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    }
    window.IrriApp && window.IrriApp.toast(name + ' hazır');
  }

  let fontCache = null;
  async function fonts() {
    if (fontCache) return fontCache;
    const get = async f => b64FromBuf(await (await fetch('vendor/fonts/' + f)).arrayBuffer());
    fontCache = { r: await get('DejaVuSansCondensed.ttf'), b: await get('DejaVuSansCondensed-Bold.ttf') };
    return fontCache;
  }
  function svgToPng(svg, w) {
    return new Promise((res, rej) => {
      const img = new Image();
      img.onload = () => { const c = document.createElement('canvas'); const k = w / img.width; c.width = w; c.height = Math.round(img.height * k); const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height); res({ data: c.toDataURL('image/png'), ratio: c.height / c.width }); };
      img.onerror = rej; img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    });
  }

  async function pdf(p, r, svg) {
    const { jsPDF } = window.jspdf; const doc = new jsPDF({ unit: 'mm', format: 'a4', compress: true });
    const f = await fonts();
    doc.addFileToVFS('dv.ttf', f.r); doc.addFont('dv.ttf', 'DV', 'normal'); doc.addFileToVFS('dvb.ttf', f.b); doc.addFont('dvb.ttf', 'DV', 'bold');
    const T = RD.build(p, r), Wd = 210, M = 14; let y = 16;
    const need = h => { if (y + h > 284) { doc.addPage(); y = 16; } };
    const h1 = t => { need(14); doc.setFont('DV', 'bold'); doc.setFontSize(12); doc.setTextColor(15, 107, 69); doc.text(t, M, y); y += 2; doc.setDrawColor(15, 107, 69); doc.line(M, y, Wd - M, y); y += 5; doc.setTextColor(20, 30, 25); };
    const kv = rows => {
      doc.setFontSize(9);
      for (const [k, v, u, d] of rows) {
        const txt = typeof v === 'number' ? `${n(v, d ?? 1)}${u ? ' ' + u : ''}` : String(v ?? '') + (u && typeof v !== 'string' ? ' ' + u : '');
        const lines = doc.splitTextToSize(txt, 104); need(lines.length * 4.4 + 1);
        doc.setFont('DV', 'normal'); doc.setTextColor(95, 111, 102); doc.text(doc.splitTextToSize(String(k), 72), M, y);
        doc.setTextColor(20, 30, 25); doc.setFont('DV', 'bold'); doc.text(lines, M + 76, y); y += lines.length * 4.4 + 0.8;
      }
      y += 3;
    };
    const table = (rows, widths, dec, alignR) => {
      doc.setFontSize(7.6);
      rows.forEach((row, ri) => {
        const cells = row.map((c, ci) => doc.splitTextToSize(ri && typeof c === 'number' ? n(c, dec[ci] ?? 1) : String(c ?? ''), widths[ci] - 1.5));
        const hh = Math.max(...cells.map(c => c.length)) * 3.5 + 1.8; need(hh);
        if (ri === 0) { doc.setFillColor(227, 242, 234); doc.rect(M, y - 3.3, Wd - 2 * M, hh, 'F'); }
        doc.setFont('DV', ri === 0 ? 'bold' : 'normal');
        let x = M; cells.forEach((c, ci) => { const right = alignR.includes(ci); doc.text(c, right ? x + widths[ci] - 1 : x + 0.5, y, { align: right ? 'right' : 'left' }); x += widths[ci]; });
        y += hh; doc.setDrawColor(221, 229, 224); doc.line(M, y - 3.3, Wd - M, y - 3.3);
      });
      y += 3;
    };
    doc.setFont('DV', 'bold'); doc.setFontSize(17); doc.setTextColor(15, 81, 50); doc.text('Damla Sulama Ön Projesi', M, y); y += 7;
    doc.setFont('DV', 'normal'); doc.setFontSize(10); doc.setTextColor(95, 111, 102); doc.text(`${p.name} · IrriSmart AI · ${new Date().toLocaleDateString('tr-TR')}`, M, y); y += 8;
    h1('Proje özeti'); kv(T.ozet);
    if (svg) { try { const img = await svgToPng(svg, 1400); const iw = Wd - 2 * M, ih = Math.min(iw * img.ratio, 200); const iw2 = ih / img.ratio; need(ih + 14); h1('Yerleşim planı'); doc.addImage(img.data, 'PNG', M + (iw - iw2) / 2, y, iw2, ih); y += ih + 6; } catch (e) { /* plan çizilemezse rapor yine üretilir */ } }
    h1('Hidrolik hesaplar'); kv(T.hidrolik);
    h1('Sektörler'); table(T.sektor, [30, 30, 40, 40], T.sektorDec, [1, 2, 3]);
    h1('Sektörleme alternatifleri'); table(T.altSek, [13, 18, 15, 13, 20, 14, 13, 19, 23, 34], T.altSekDec, [0, 1, 2, 5, 6, 7, 8]);
    h1('Ana hat alternatifleri'); table(T.altHat, [11, 9, 13, 13, 15, 19, 19, 19, 19, 45], T.altHatDec, [0, 1, 2, 3, 4, 5, 6, 7, 8]);
    h1('Su ihtiyacı ve sulama programı'); kv(T.su); table(T.prog, [20, 18, 24, 24, 24, 38, 34], T.progDec, [1, 2, 3, 4, 5, 6]);
    h1('Malzeme listesi — fiyatlı kalemler'); table(T.bomP, [18, 66, 17, 11, 21, 23, 26], T.bomDec, [2, 4, 5]);
    if (T.bomU.length > 1) { h1('Malzeme listesi — fiyatı eksik kalemler'); table(T.bomU, [24, 110, 24, 24], T.bomDec, [2]); }
    h1('Maliyet'); kv(T.toplam);
    if (r.warn.length) { h1('Uyarılar'); kv(r.warn.map((w, i) => [String(i + 1), w, '', null])); }
    h1('Varsayımlar'); kv(r.asm.map((a, i) => [String(i + 1), a, '', null]));
    need(18); doc.setFont('DV', 'normal'); doc.setFontSize(8); doc.setTextColor(95, 111, 102);
    doc.text(doc.splitTextToSize('Bu rapor ön projelendirme amaçlıdır. Hesaplar FAO-56, Keller & Bliesner, Watters-Keller ve Hazen-Williams (C=150) bağıntılarıyla yapılmıştır. "Jenerik" veya "örnek" olarak işaretli ekipman ve fiyatlar gerçek ürün verisi değildir; uygulama öncesi saha ölçümü, su analizi ve üretici kataloğu değerleriyle kontrol edilmelidir.', Wd - 2 * M), M, y);
    const pages = doc.getNumberOfPages(); for (let i = 1; i <= pages; i++) { doc.setPage(i); doc.setFontSize(8); doc.text(`${i} / ${pages}`, Wd - M, 292, { align: 'right' }); }
    await saveFile(`IrriSmart_${safe(p.name)}.pdf`, doc.output('datauristring').split(',')[1], 'application/pdf');
  }

  async function xlsx(p, r) {
    const b64 = XLSX.write(RD.workbook(XLSX, p, r), { bookType: 'xlsx', type: 'base64' });
    await saveFile(`IrriSmart_${safe(p.name)}.xlsx`, b64, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  }
  async function json(name, obj) { await saveFile(name, btoa(unescape(encodeURIComponent(JSON.stringify(obj, null, 2)))), 'application/json'); }

  window.IrriReport = { pdf, xlsx, json };
})();
