# IrriGrow v0.4.0 — Damla sulama ön projelendirme (Android)

## Dosya yapısı
| Dosya | Görev |
|---|---|
| `www/js/validate.js` | Girdi doğrulama (aralık, negatif, virgüllü sayı, seçimler) |
| `www/js/hydraulics.js` | Watters-Keller, Hazen-Williams, Christiansen, adım adım lateral/manifold |
| `www/js/geom.js` | Yerel koordinat, döndürme, sıra-sınır kesişimi, kırpma, eğim düzlemi |
| `www/js/layout.js` | Parsel üzerinde sıra, lateral, manifold ve alt ünite yerleşimi; sektör bölme |
| `www/js/catalog-data.js` | Varsayılan katalog (boru: standart nominal ölçüler; pompa/filtre/vana: JENERİK) |
| `www/js/catalog.js` | Pompa (eğri), filtre, vana seçimi; katalog doğrulama/birleştirme; fiyat önceliği |
| `www/js/engine.js` | Tasarım akışı, sektör alternatifleri, sulama programı, malzeme ve maliyet |
| `www/js/report-data.js` | PDF/Excel ortak tabloları (değerler sayı, birim ayrı sütun) |
| `www/js/hydro-table.js` | Hidrolik Hesap Tablosu: kullanıcının Excel'indeki SİSTEM ve IRRIFRICT sayfalarının birebir karşılığı |
| `www/js/pipelib.js` | Excel'deki ANA BORULAR kütüphanesi (395 kayıt) |
| `www/js/i18n.js`, `i18n-dict.js` | 8 dil: tr, en, de, es, ru, it, he (sağdan sola), zh |
| `tools/verify-excel.js` | LibreOffice ile bağımsız Excel doğrulaması (CI dışında) |
| `test/*.test.js` | 63 otomatik test (`npm test`) |
| `ci/build-apk.sh` | APK derleme betiği (CI ve yerelde) |

## Katalog yükleme
Ayarlar → Ekipman kataloğu → **Şablon indir**, üretici verileriyle doldurun, **Katalog yükle**.
Pompa eğrisi `[Q m³/h, H m, verim %]` noktalarıdır. `"dogrulandi": true` kayıtlar raporda doğrulanmış görünür;
`"yalnizKullanici": {"pompa": true}` jenerik pompaları devre dışı bırakır. Kayıtlardaki `fiyat` malzeme listesine geçer.

## APK derleme (GitLab, telefondan)
1. Projeye `irrismart-src.zip` ve `.gitlab-ci.yml` yükleyin (telefonda nokta sorun çıkarırsa dosyayı `gitlab-ci.yml` adıyla yükleyip
   Settings → CI/CD → General pipelines → CI/CD configuration file alanına `gitlab-ci.yml` yazın).
2. Build → Pipelines: `test` sonra `apk` işi çalışır. İlk derleme 10–15 dk.
3. `apk` işi → Download artifacts → `IrriSmart-AI-debug.apk` (GitHub Actions).

Not: gitlab.com paylaşımlı runner'ları için hesap doğrulaması (telefon/kart) istenebilir.

## Yerelde
```
npm ci && npm test
bash ci/build-apk.sh     # JDK 17 + internet gerekir
```
