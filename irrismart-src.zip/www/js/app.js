// IrriGrow — arayüz
(function () {
  const D = window.IRRI_DATA, E = window.IrriEngine, V = window.IrriValidate, Ct = window.IrriCatalog, Gm = window.IrriGeom, HT = window.IrriHydroTable, I = window.IrriI18n;
  const t = I.t;
  const $ = s => document.querySelector(s);
  const KEY = 'irrismart.projects.v1', SKEY = 'irrismart.settings.v1', CKEY = 'irrismart.catalog.v1';
  const fmt = (v, d = 1) => (v == null || !Number.isFinite(Number(v))) ? '—' : Number(v).toLocaleString(I.locale, { minimumFractionDigits: d, maximumFractionDigits: d });
  const tl = v => v == null ? '—' : fmt(v, 0) + ' ₺';
  // Giriş kutusunda sayıyı seçili dilin ondalık işaretiyle göster (ayrıştırıcı nokta ve virgülü kabul eder)
  const inVal = v => typeof v === 'number' ? String(v).replace('.', (1.5).toLocaleString(I.locale).charAt(1)) : (v ?? '');
  const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const SRC = () => ({ kullanici: t('kullanıcı'), katalog: t('katalog'), ornek: t('örnek') });

  // ---------- Depolama ----------
  function load(k, def) { try { const v = JSON.parse(localStorage.getItem(k)); return v ?? def; } catch (e) { return def; } }
  function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { toast(t('Kayıt hatası: ') + e.message); return false; } }
  // Projeler: bozuk veya geçersiz kayıtlar silinmez, kurtarma anahtarına taşınır; şema değişiminden önce ham yedek alınır
  const St = window.IrriStore;
  let projects = (() => {
    let raw = null; try { raw = localStorage.getItem(KEY); } catch (e) { }
    const r = St.parseProjects(raw);
    try {
      if (r.rescue) localStorage.setItem('irrigrow.rescue.' + Date.now(), r.rescue);
      if (r.migrated && raw && !localStorage.getItem('irrigrow.premigration.v1')) localStorage.setItem('irrigrow.premigration.v1', raw);
    } catch (e) { }
    if (r.corrupt) setTimeout(() => toast(t('Proje kaydı okunamadı; ham veri kurtarma alanına kopyalandı.')), 500);
    return r.projects;
  })();
  let settings = Object.assign(JSON.parse(JSON.stringify(D.DEFAULT_PRICES)), { items: {}, edited: {} }, load(SKEY, {}));
  settings.items = settings.items || {}; settings.edited = settings.edited || {};
  let userCat = load(CKEY, null);
  let catalog = Ct.mergeCatalog(window.IRRI_CATALOG, userCat);
  let cur = null, lastRes = null, altCache = null;
  const persist = () => { if (cur) cur.updated = Date.now(); save(KEY, projects); };
  const saveSettings = () => { save(SKEY, settings); lastRes = null; };

  function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('on'), 3000); }
  function safely(fn, where) { try { return fn(); } catch (e) { console.error(e); toast(`${where}: ${t('beklenmeyen hata')} (${e.message})`); } }

  // ---------- Gezinme ----------
  function show(v) {
    if (v !== 'projeler' && v !== 'ayarlar' && !cur) { toast(t('Önce bir proje açın veya oluşturun')); v = 'projeler'; }
    if (v !== 'arazi') document.body.classList.remove('mapfull');
    document.querySelectorAll('.view').forEach(e => e.classList.toggle('on', e.id === 'v-' + v));
    document.querySelectorAll('nav.tabs button').forEach(b => b.classList.toggle('on', b.dataset.v === v));
    safely(() => ({ projeler: renderProjects, arazi: openMap, veri: renderForm, sonuc: renderResult, malzeme: renderBom, ayarlar: renderSettings, hidrolik: renderHydro })[v](), t('Ekran'));
  }
  document.querySelectorAll('nav.tabs button').forEach(b => b.onclick = () => show(b.dataset.v));
  $('#btnBack').onclick = () => show('projeler');
  $('#btnSettings').onclick = () => show('ayarlar');

  // ---------- Projeler ----------
  function newProject() {
    const name = (prompt(t('Proje adı:'), t('Yeni proje') + ' ' + (projects.length + 1)) || '').trim();
    if (!name) return;
    const p = { id: Date.now().toString(36), name: name.slice(0, 80), created: Date.now(), updated: Date.now(), poly: [], src: null, inp: { crop: 'domates', srcType: 'kuyu', region: 'akdeniz', soil: 'tinli', rowDir: 'uzun', emitter: 'normal', geom: 'dikdortgen' } };
    projects.unshift(p); persist(); openProject(p.id); show('arazi');
  }
  function openProject(id) { cur = projects.find(p => p.id === id) || null; lastRes = null; overlayRes = null; $('#projName').textContent = cur ? cur.name : t('Proje seçilmedi'); }
  function renderProjects() {
    const el = $('#projList');
    if (!projects.length) { el.innerHTML = `<div class="card center muted">${t('Henüz proje yok.')}<br>${t('“Yeni proje” ile başlayın.')}</div>`; return; }
    el.innerHTML = projects.map(p => {
      const c = D.CROPS[p.inp.crop]; const a = V.parseNum(p.inp.area_da); const da = a > 0 ? fmt(a, 1) + ' da' : t('alan yok');
      return `<div class="proj"><div class="t" data-open="${p.id}"><b>${esc(p.name)}</b><span class="muted small">${c ? t(c.ad) : ''} · ${da}${p.inp.geom === 'parsel' ? ' · ' + t('parsel') : ''} · ${new Date(p.updated).toLocaleDateString(I.locale)}</span></div>
      <button class="btn sm" data-ren="${p.id}" aria-label="${t('Yeniden adlandır')}">✎</button><button class="btn sm" data-copy="${p.id}" aria-label="${t('Kopyala')}">⧉</button><button class="btn sm danger" data-del="${p.id}" aria-label="${t('Sil')}">✕</button></div>`;
    }).join('');
    el.querySelectorAll('[data-open]').forEach(b => b.onclick = () => { openProject(b.dataset.open); show(cur.inp.Q ? 'sonuc' : 'arazi'); });
    el.querySelectorAll('[data-del]').forEach(b => b.onclick = () => { const p = projects.find(x => x.id === b.dataset.del); if (confirm(t('“{n}” silinsin mi?', { n: p.name }))) { projects = projects.filter(x => x !== p); if (cur === p) { cur = null; $('#projName').textContent = t('Proje seçilmedi'); } persist(); renderProjects(); } });
    el.querySelectorAll('[data-copy]').forEach(b => b.onclick = () => { const p = projects.find(x => x.id === b.dataset.copy); const c = St.duplicate(p, t('kopya')); projects.unshift(c); persist(); renderProjects(); });
    el.querySelectorAll('[data-ren]').forEach(b => b.onclick = () => { const p = projects.find(x => x.id === b.dataset.ren); const nm = (prompt(t('Yeni ad:'), p.name) || '').trim(); if (nm) { p.name = nm.slice(0, 80); persist(); if (cur === p) $('#projName').textContent = p.name; renderProjects(); } });
  }
  $('#btnNew').onclick = newProject;
  // Yedekleme: tüm projeler + ayarlar + kullanıcı kataloğu tek JSON dosyasında
  $('#btnBackup').onclick = () => {
    if (!projects.length) return toast(t('Yedeklenecek proje yok'));
    window.IrriReport.json('IrriGrow_yedek', { uygulama: 'IrriGrow', yedekSurum: 1, tarih: new Date().toISOString(), projects, settings, catalog: userCat }).catch(e => toast(t('Yedek alınamadı: ') + e.message));
  };
  $('#restoreFile').onchange = async ev => {
    const f = ev.target.files[0]; ev.target.value = ''; if (!f) return;
    try {
      const j = JSON.parse(await f.text());
      if (!j || !['IrriGrow', 'IrriSmart'].includes(j.uygulama) || !Array.isArray(j.projects)) throw new Error(t('Bu bir IrriGrow yedek dosyası değil'));
      const valid = j.projects.filter(p => p && typeof p.id === 'string' && p.inp && typeof p.inp === 'object');
      const same = valid.filter(p => projects.some(x => x.id === p.id)).length;
      if (!confirm(t('{n} proje yüklenecek.', { n: valid.length }) + (same ? ' ' + t('{n} tanesi mevcut projelerin üzerine yazılacak.', { n: same }) : '') + ' ' + t('Devam edilsin mi?'))) return;
      for (const p of valid) { const i = projects.findIndex(x => x.id === p.id); const q = St.migrateProject(p); if (i >= 0) projects[i] = q; else projects.push(q); }
      projects.sort((a, b) => (b.updated || 0) - (a.updated || 0));
      if (j.settings && typeof j.settings === 'object' && confirm(t('Yedekteki fiyat ayarları da yüklensin mi?'))) { settings = Object.assign(JSON.parse(JSON.stringify(D.DEFAULT_PRICES)), { items: {}, edited: {} }, j.settings); saveSettings(); }
      if (j.catalog && !Ct.checkCatalog(j.catalog).length) { userCat = j.catalog; save(CKEY, userCat); catalog = Ct.mergeCatalog(window.IRRI_CATALOG, userCat); }
      persist(); cur = null; $('#projName').textContent = t('Proje seçilmedi'); renderProjects(); toast(t('{n} proje yüklendi', { n: valid.length }));
    } catch (e) { alert(t('Yedek yüklenemedi: ') + e.message); }
  };

  // ---------- Harita ----------
  // Renkler: ana hat kırmızı, manifold mavi, lateral yeşil, shift bölgeleri yarı saydam, su kaynağı turkuaz
  const COL = { main: '#d32f2f', man: '#1565c0', lat: '#2e9d4f', src: '#00bcd4', edge: '#ffd400' };
  let map, poly, markers = [], extra = [], planLayer = null, mapMode = 'sinir', overlayRes = null, showPlan = true, brush = 0, legend = null;
  function openMap() {
    if (!map) {
      map = L.map('map', { zoomControl: true, preferCanvas: true }).setView([38.5, 33.5], 6);
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: 'Esri, Maxar' }).addTo(map);
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, opacity: .8 }).addTo(map);
      map.on('click', e => {
        const ll = [e.latlng.lat, e.latlng.lng];
        if (mapMode === 'shift') return;
        if (mapMode === 'kaynak') { cur.src = ll; setMode('sinir'); }
        else if (mapMode === 'istasyon') { cur.station = ll; setMode('sinir'); }
        else if (mapMode === 'anahat') (cur.route = cur.route || []).push(ll);
        else cur.poly.push(ll);
        invalidateDesign(); persist(); drawPoly();
      });
      legend = L.DomUtil.create('div', 'mlegend'); legend.innerHTML = `<div><i style="background:${COL.main}"></i>${t('Ana hat')}</div><div><i style="background:${COL.man}"></i>Manifold</div><div><i style="background:${COL.lat}"></i>Lateral</div><div><i style="background:${COL.src};height:8px;width:8px;border-radius:50%"></i>${t('Kaynak')}</div>`;
      $('#map').appendChild(legend);
      const zc = () => $('#map').classList.toggle('zsmall', map.getZoom() < 17); map.on('zoomend', zc); zc();
    }
    setMode(mapMode);
    if (showPlan && !overlayRes && cur.inp.geom === 'parsel' && cur.poly.length >= 3) safely(() => compute(), 'Plan');
    setTimeout(() => { map.invalidateSize(); drawPoly(true); }, 50);
  }
  function invalidateDesign() { lastRes = null; overlayRes = null; altCache = null; }
  function setMode(m) {
    mapMode = m;
    document.querySelectorAll('#mModes button').forEach(b => b.classList.toggle('on', b.dataset.m === m));
    const bar = $('#mShiftBar');
    if (m === 'shift') {
      const r = overlayRes && overlayRes.ok ? overlayRes : null;
      const n = r ? r.sel.groups.length : 0;
      bar.style.display = 'flex';
      bar.innerHTML = r ? `<span class="small">${t('Atanacak shift')}:</span> ${Array.from({ length: n + 1 }, (_, j) => `<button class="btn sm ${brush === j ? 'primary' : ''}" data-b="${j}" style="flex:none;min-width:38px"><span class="dot" style="background:${PALETTE[j % PALETTE.length]}"></span>${j + 1}${j === n ? '+' : ''}</button>`).join('')} <button class="btn sm" id="mAuto" style="flex:none">${t('Otomatik')}</button>`
        : `<span class="small">${t('Önce “Uygula” ile parsel planını oluşturun.')}</span>`;
      bar.querySelectorAll('[data-b]').forEach(x => x.onclick = () => { brush = +x.dataset.b; setMode('shift'); });
      const au = $('#mAuto'); if (au) au.onclick = () => { delete cur.shiftEdit; invalidateDesign(); persist(); compute(); setMode('shift'); drawPoly(); toast(t('Otomatik shift’lere dönüldü')); };
    } else bar.style.display = 'none';
    document.documentElement.style.setProperty('--mapbar', (m === 'shift' ? 196 : 150) + 'px');
    if (map) setTimeout(() => map.invalidateSize(), 30);
    drawInfo();
  }
  document.querySelectorAll('#mModes button').forEach(b => b.onclick = () => { setMode(mapMode === b.dataset.m && b.dataset.m !== 'sinir' ? 'sinir' : b.dataset.m); drawPoly(); });
  function vtx(ll, cls, onMove, html, size = 16) {
    const m = L.marker(ll, { draggable: true, icon: L.divIcon({ className: cls, html: html || '', iconSize: [size, size] }) }).addTo(map);
    m.on('dragend', ev => { const p = ev.target.getLatLng(); onMove([p.lat, p.lng]); invalidateDesign(); persist(); drawPoly(); });
    extra.push(m); return m;
  }
  function drawPoly(fit) {
    if (poly) map.removeLayer(poly); poly = null;
    [...markers, ...extra].forEach(m => map.removeLayer(m)); markers = []; extra = [];
    const pts = cur.poly;
    if (pts.length) {
      poly = (pts.length >= 3 ? L.polygon(pts, { color: COL.edge, weight: 2, fillOpacity: .08, interactive: false }) : L.polyline(pts, { color: COL.edge, weight: 2, interactive: false })).addTo(map);
      if (mapMode === 'sinir') pts.forEach((p, i) => markers.push(vtx(p, 'vtx', q => { cur.poly[i] = q; })));
      if (fit && pts.length >= 2) map.fitBounds(poly.getBounds(), { padding: [30, 30], maxZoom: 18 });
    }
    // Ana hat güzergâhı (kullanıcı çizimi): kaynak → istasyon → noktalar
    const chain = [cur.src, cur.station, ...(cur.route || [])].filter(Boolean);
    if ((cur.route || []).length && chain.length >= 2) extra.push(L.polyline(chain, { color: COL.main, weight: 4, dashArray: mapMode === 'anahat' ? '8 6' : null, interactive: false }).addTo(map));
    if (mapMode === 'anahat') (cur.route || []).forEach((p, i) => vtx(p, 'rtv', q => { cur.route[i] = q; }, '', 14));
    if (cur.src) vtx(cur.src, 'srcm', q => { cur.src = q; }, 'K', 22).bindTooltip(t('Su kaynağı'));
    if (cur.station) vtx(cur.station, 'stam', q => { cur.station = q; }, 'P+F', 30).bindTooltip(t('Pompa ve filtre istasyonu'));
    drawPlan();
    drawInfo();
  }
  function drawInfo() {
    const pts = cur ? cur.poly : [], el = $('#mapInfo'); if (!el || !cur) return;
    const hint = { kaynak: t('Kaynak (kuyu/pompa) noktasına dokunun.'), istasyon: t('Pompa ve filtre istasyonunun yerine dokunun.'), anahat: t('Ana hat güzergâhını kaynaktan araziye doğru noktalarla çizin. Noktalar sürüklenebilir.'), shift: t('Bir alt üniteye dokunarak seçili shift’e atayın.') }[mapMode];
    if (hint) { el.textContent = hint + ((cur.route || []).length && mapMode === 'anahat' ? ' · ' + t('{n} nokta', { n: cur.route.length }) : ''); return; }
    if (pts.length >= 3) {
      const f = Gm.fieldFromPolygon(pts);
      el.innerHTML = `<b>${fmt(f.A / 1000, 2)} ${t('dekar')}</b> (${fmt(f.A / 10000, 2)} ha) · ${t('{n} köşe', { n: pts.length })}${cur.src ? ' · ' + t('kaynak işaretli') : ''}${f.selfX ? ' · <span class="bad">' + t('sınır kendini kesiyor') + '</span>' : f.fill < 0.8 ? ' · ' + t('düzensiz şekil') : ''}`;
    } else el.textContent = pts.length ? t('{n} köşe — en az 3 köşe gerekli.', { n: pts.length }) : t('Haritada arazinin köşelerine sırayla dokunun. Köşeler sürüklenebilir.');
  }
  const tbl = rows => `<table>${rows.map(([a, b]) => `<tr><td>${a}</td><td><b>${b}</b></td></tr>`).join('')}</table>`;
  // Tasarım planını harita üzerinde göster; borulara dokununca bilgi kartı
  function drawPlan() {
    if (planLayer) { map.removeLayer(planLayer); planLayer = null; }
    const r = overlayRes;
    if (!showPlan || !r || !r.ok || r.layout.mode !== 'parsel') return;
    const Ly = r.layout, ll = p => { const [x, y] = Gm.unrot(p, Ly.angle); return Gm.fromLocal(x, y, Ly.lat0, Ly.lng0); };
    const g = L.layerGroup(), rend = L.canvas({ padding: 0.3, tolerance: 8 });
    const secOf = sectorIndex(r), pal = PALETTE, m = r.main.sel, s = r.schedule;
    r.units.forEach((u, k) => {
      const b = Ly.bands[u.band]; const c = Gm.clipRect(Ly.P, b.x0, b.x1, u.y0, u.y1); if (c.length < 3) return;
      const pg = L.polygon(c.map(ll), { renderer: rend, stroke: mapMode === 'shift', color: '#fff', weight: 1, fillColor: pal[secOf[k] % pal.length], fillOpacity: .38 }).addTo(g);
      if (mapMode === 'shift') pg.on('click', () => assignUnit(r, k));
      else pg.bindPopup(() => `<b>Shift ${secOf[k] + 1}</b> · ${t('alt ünite')} ${k + 1}` + tbl([[t('Debi'), fmt(u.Q, 2) + ' m³/h'], [t('Lateral'), fmt(u.nLat, 0)], [t('Giriş basıncı'), fmt(u.hIn, 1) + ' m']]));
    });
    const step = Math.max(1, Math.ceil(Ly.laterals.length / 2500));
    for (let i = 0; i < Ly.laterals.length; i += step) {
      const l = Ly.laterals[i];
      L.polyline([ll([l.ax, l.y]), ll([l.ax + l.side * l.len, l.y])], { renderer: rend, color: COL.lat, weight: 1.2, opacity: .85, interactive: mapMode !== 'shift' }).addTo(g)
        .bindPopup(() => `<b>Lateral Ø${r.lateral.d}</b>` + tbl([[t('İç çap'), fmt(r.lateral.ic, 1) + ' mm'], [t('Uzunluk'), fmt(l.len, 1) + ' m'], [t('Damlatıcı'), fmt(l.N, 0)], [t('Debi'), fmt(l.Q, 0) + ' l/h'], [t('Sürtünme kaybı'), fmt(l.hf, 2) + ' m'], [t('Basınç farkı'), fmt(l.dH, 2) + ' m'], [t('Giriş basıncı'), fmt(l.hreq, 1) + ' m'], [t('Malzeme'), 'PE']]));
    }
    const Qm = r.sel.Qmax, Hy = window.IrriHyd;
    mainLines(r).forEach(seg => {
      const Ls = seg.reduce((t0, p, i) => i ? t0 + Math.hypot(p[0] - seg[i - 1][0], p[1] - seg[i - 1][1]) : 0, 0);
      const hf = Hy.hfHW(Qm / 3600, m.ic / 1000, Ls) * 1.10;
      L.polyline(seg.map(ll), { renderer: rend, color: COL.main, weight: 6, interactive: mapMode !== 'shift' }).addTo(g)
        .bindPopup(() => `<b>${t('Ana hat')} PVC-U Ø${m.od} PN${m.pn}</b>` + tbl([[t('İç çap'), fmt(m.ic, 1) + ' mm'], [t('Uzunluk'), fmt(Ls, 1) + ' m'], [t('Debi (en büyük shift)'), fmt(Qm, 1) + ' m³/h'], [t('Hız'), fmt(m.v, 2) + ' m/s'], [t('Sürtünme kaybı'), fmt(hf, 2) + ' m'], [t('Malzeme'), 'PVC-U']]) + `<div class="small muted">Hazen-Williams C=150, +%10 ${t('yerel kayıp')}</div>`);
    });
    r.units.forEach((u, k) => L.polyline([ll([u.ax, u.yIn]), ll([u.ax, u.yEnd])], { renderer: rend, color: COL.man, weight: 4, interactive: mapMode !== 'shift' }).addTo(g)
      .bindPopup(() => `<b>Manifold Ø${u.pipe.od} PN${u.pipe.pn}</b> · Shift ${secOf[k] + 1}` + tbl([[t('İç çap'), fmt(u.pipe.ic, 1) + ' mm'], [t('Uzunluk'), fmt(u.Lm, 1) + ' m'], [t('Debi'), fmt(u.Q, 2) + ' m³/h'], [t('Hız'), fmt(u.v, 2) + ' m/s'], [t('Sürtünme kaybı'), fmt(u.hf, 2) + ' m'], [t('Basınç farkı'), fmt(u.varH, 2) + ' m'], [t('Giriş basıncı'), fmt(u.hIn, 1) + ' m'], [t('Malzeme'), u.pipe.malzeme || 'PE100']])));
    // Shift etiketleri: alan · debi · basınç · süre (her shift'in en büyük alt ünitesinde)
    r.sel.groups.forEach((gr, j) => {
      const k = gr.reduce((a, b) => r.units[b].Q > r.units[a].Q ? b : a, gr[0]), u = r.units[k];
      const A = gr.reduce((x, q) => x + r.units[q].Q, 0) / r.sectors.Qfield * r.field.da;
      L.marker(ll([u.ax, (u.yIn + u.yEnd) / 2]), { interactive: false, icon: L.divIcon({ className: 'slab', html: `<b>S${j + 1}</b><span class="d"> · ${fmt(A, 1)} da<br>${fmt(r.sel.Qj[j], 1)} m³/h · ${fmt(m.H[j], 0)} m · ${fmt(s.t, 1)} h</span>`, iconSize: null }) }).addTo(g);
    });
    planLayer = g.addTo(map);
  }
  function assignUnit(r, k) {
    const cur0 = sectorIndex(r);
    const assign = cur.shiftEdit && cur.shiftEdit.sig === r.layout.sig ? cur.shiftEdit.assign.slice() : cur0.slice();
    assign[k] = brush;
    // boş kalan shift numaralarını sıkıştır
    const ids = [...new Set(assign)].sort((a, b) => a - b); const map2 = new Map(ids.map((v, i) => [v, i]));
    cur.shiftEdit = { sig: r.layout.sig, assign: assign.map(v => map2.get(v)) };
    brush = Math.min(brush, ids.length);
    invalidateDesign(); persist(); const r2 = compute();
    if (r2.ok && r2.sel.overSource) toast(t('Bu shift kaynak debisini aşıyor'));
    setMode('shift'); drawPoly();
  }
  $('#mUndo').onclick = () => { if (mapMode === 'anahat') (cur.route || []).pop(); else if (mapMode === 'istasyon') cur.station = null; else cur.poly.pop(); invalidateDesign(); persist(); drawPoly(); };
  $('#mClear').onclick = () => {
    if (mapMode === 'anahat') { if (confirm(t('Ana hat güzergâhı silinsin mi?'))) { cur.route = []; invalidateDesign(); persist(); drawPoly(); } return; }
    if (confirm(t('Sınır ve kaynak noktası silinsin mi?'))) { cur.poly = []; cur.src = null; cur.station = null; cur.route = []; delete cur.shiftEdit; delete cur.inp.grad; invalidateDesign(); persist(); drawPoly(); }
  };
  $('#mFull').onclick = () => { document.body.classList.toggle('mapfull'); setTimeout(() => map && map.invalidateSize(), 60); };
  $('#mPlan').onclick = () => { showPlan = !showPlan; if (showPlan) { const r = overlayRes || compute(); if (!r.ok) toast(t('Plan çizilemedi: ') + r.err[0]); else if (r.layout.mode !== 'parsel') toast(t('Harita planı için önce “Uygula” deyin (gerçek parsel modu)')); } $('#mPlan').classList.toggle('primary', showPlan && !!overlayRes); drawPoly(); };
  $('#mGps').onclick = async () => {
    try {
      const native = window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform();
      let pos;
      const Geo = native ? window.IrriReport.plugin('Geolocation') : null;
      if (Geo) { try { await Geo.requestPermissions(); } catch (e) { } pos = await Geo.getCurrentPosition({ enableHighAccuracy: true, timeout: 15000 }); }
      else pos = await new Promise((res, rej) => navigator.geolocation.getCurrentPosition(res, rej, { enableHighAccuracy: true, timeout: 15000 }));
      map.setView([pos.coords.latitude, pos.coords.longitude], 17);
    } catch (e) { toast(t('Konum alınamadı: ') + (e.message || e)); }
  };
  $('#mApply').onclick = async () => {
    const pts = cur.poly; if (pts.length < 3) return toast(t('En az 3 köşe işaretleyin'));
    const f = Gm.fieldFromPolygon(pts);
    if (f.selfX) return toast(t('Sınır kendini kesiyor; köşeleri düzeltin'));
    Object.assign(cur.inp, { area_da: +(f.A / 1000).toFixed(2), L: +f.L.toFixed(1), W: +f.W.toFixed(1), geom: 'parsel' });
    invalidateDesign(); persist();
    toast(t('Parsel aktarıldı. Eğim ölçülüyor…'));
    try {
      const s = await measureSlope(pts, f.box.deg);
      if (s) {
        Object.assign(cur.inp, { slopeLong: +Math.abs(s.alongLong).toFixed(2), slopeShort: +Math.abs(s.alongShort).toFixed(2), grad: { gx: s.gx, gy: s.gy } });
        cur.elev = { zmin: s.zmin, zmax: s.zmax, total: s.total, src: 'Open-Meteo (Copernicus DEM ~90 m)' }; persist();
        toast(t('Eğim: uzun kenar %{a}, kısa kenar %{b} (kot {c}–{d} m)', { a: fmt(Math.abs(s.alongLong), 2), b: fmt(Math.abs(s.alongShort), 2), c: fmt(s.zmin, 0), d: fmt(s.zmax, 0) }));
      }
    } catch (e) { toast(t('Eğim alınamadı (internet?) — Veriler ekranından elle girin.')); }
    setTimeout(() => show('veri'), 1400);
  };
  async function measureSlope(pts, deg) {
    const lats = pts.map(p => p[0]), lngs = pts.map(p => p[1]);
    const inside = (x, y) => { let c = false; for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) { const [yi, xi] = pts[i], [yj, xj] = pts[j]; if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) c = !c; } return c; };
    const sample = pts.slice(0, 40);
    const [a, b, c, d] = [Math.min(...lats), Math.max(...lats), Math.min(...lngs), Math.max(...lngs)];
    for (let i = 1; i < 7; i++) for (let j = 1; j < 7; j++) { const y = a + (b - a) * i / 7, x = c + (d - c) * j / 7; if (inside(x, y)) sample.push([y, x]); }
    const url = `https://api.open-meteo.com/v1/elevation?latitude=${sample.map(p => p[0].toFixed(6)).join(',')}&longitude=${sample.map(p => p[1].toFixed(6)).join(',')}`;
    const r = await fetch(url); if (!r.ok) throw new Error(r.status);
    const j = await r.json(); if (!Array.isArray(j.elevation) || j.elevation.length !== sample.length) throw new Error('yükseklik verisi eksik');
    return Gm.slopeFromPoints(sample, j.elevation, deg);
  }

  // ---------- Veri formu ----------
  const opts = o => Object.entries(o).map(([k, v]) => [k, v.ad]);
  const FORM = [
    ['Arazi', [
      ['geom', 'Tasarım geometrisi', [['dikdortgen', 'Eşdeğer dikdörtgen'], ['parsel', 'Gerçek parsel sınırı']], null, 'one'],
      ['area_da', 'Alan (dekar)', 'num', null, null, (c, i) => i.geom === 'parsel'], ['rowDir', 'Sıra yönü', [['uzun', 'Uzun kenara paralel'], ['kisa', 'Kısa kenara paralel']]],
      ['L', 'Uzun kenar (m)', 'num', null, null, (c, i) => i.geom === 'parsel'], ['W', 'Kısa kenar (m)', 'num', null, null, (c, i) => i.geom === 'parsel'],
      ['slopeLong', 'Uzun kenar eğimi (%)', 'num', '0'], ['slopeShort', 'Kısa kenar eğimi (%)', 'num', '0'],
      ['nB', 'Manifold hattı sayısı', 'num', 'otomatik'],
    ]],
    ['Bitki ve iklim', [
      ['crop', 'Bitki', opts(D.CROPS), null, 'one'],
      ['Sr', 'Sıra arası (m)', 'num', c => c.Sr], ['Sp', 'Sıra üzeri (m)', 'num', c => c.Sp],
      ['region', 'Bölge', opts(D.REGIONS)], ['et0', 'Tepe ET0 (mm/gün)', 'num', (c, i) => (D.REGIONS[i.region] || {}).et0],
      ['soil', 'Toprak', opts(D.SOILS)], ['interval', 'Sulama aralığı (gün)', 'num', 'otomatik'],
    ]],
    ['Damla sistemi', [
      ['emitter', 'Damlatıcı tipi', [['normal', 'Normal'], ['pc', 'Basınç ayarlı (PC)']]], ['latD', 'Lateral çapı', [['', 'Otomatik'], ['16', 'Ø16 mm'], ['20', 'Ø20 mm']]],
      ['q', 'Damlatıcı debisi (l/h)', 'num', c => c.tip === 'agac' ? 4 : 2], ['Se', 'Damlatıcı aralığı (m)', 'num', '0,33', null, c => c.tip === 'agac'],
      ['ne', 'Ağaç başına damlatıcı', 'num', c => c.ne, null, c => c.tip !== 'agac'],
      ['hNom', 'Çalışma basıncı (m)', 'num', '10', null, (c, i) => i.emitter === 'pc'],
      ['pcMin', 'PC min. basınç (m)', 'num', '10', null, (c, i) => i.emitter !== 'pc'], ['pcMax', 'PC maks. basınç (m)', 'num', '30', null, (c, i) => i.emitter !== 'pc'],
    ]],
    ['Su kaynağı', [
      ['srcType', 'Kaynak', [['kuyu', 'Kuyu'], ['yuzey', 'Göl/kanal/havuz'], ['sebeke', 'Şebeke/hidrant']]],
      ['Q', 'Debi (m³/h) *', 'num', 'zorunlu'],
      ['depth', 'Dinamik seviye / emme (m)', 'num', (c, i) => i.srcType === 'kuyu' ? 30 : 2, null, (c, i) => i.srcType === 'sebeke'],
      ['pAvail', 'Mevcut basınç (bar)', 'num', 'bilinmiyor', null, (c, i) => i.srcType !== 'sebeke'],
      ['waterQ', 'Su kalitesi', [['', 'Bilinmiyor/kumlu'], ['temiz', 'Temiz']], null, null, (c, i) => i.srcType !== 'kuyu'],
      ['dSource', 'Kaynak–arazi mesafesi (m)', 'num', '0', null, (c, i) => i.geom === 'parsel' && cur && cur.src],
      ['dZ', 'Kaynak→arazi kot farkı (m)', 'num', '0'],
      ['hours', 'Günlük çalışma (saat)', 'num', '20'],
    ]],
  ];
  function renderForm() {
    const i = cur.inp, c = D.CROPS[i.crop] || {};
    const val = V.validate(i);
    const nErr = Object.keys(val.errors).length;
    const pa = i.geom === 'parsel' && (cur.poly || []).length >= 3 ? Gm.fieldFromPolygon(cur.poly) : null;
    $('#form').innerHTML = (pa ? `<div class="note" style="background:var(--pri2)">${t('Parsel alanı')} <b>${fmt(pa.A / 1000, 2)} da</b> — ${t('tasarım haritadaki gerçek sınır üzerinde yapılır.')}</div>` : '') + (nErr ? `<div class="note err">${t('{n} alanda hata var. Düzeltilmeden hesaplama yapılmaz.', { n: nErr })}</div>` : '') +
      FORM.map(([title, fields]) => `<fieldset><legend>${t(title)}</legend><div class="f">${fields.map(([k, lab, type, ph, cls, hide]) => {
        if (hide && hide(c, i)) return '';
        let phv = typeof ph === 'function' ? ph(c, i) : ph; if (typeof phv === 'string' && !/^[\d.,]+$/.test(phv)) phv = t(phv);
        const bad = val.errors[k];
        const field = Array.isArray(type)
          ? `<select name="${k}">${type.map(([v, tx]) => `<option value="${v}" ${String(i[k] ?? '') === v ? 'selected' : ''}>${t(tx)}</option>`).join('')}</select>`
          : `<input name="${k}" type="text" inputmode="decimal" value="${esc(i[k] ?? '')}" placeholder="${esc(String(phv ?? '').replace('.', ','))}" class="${bad ? 'bad' : ''}">`;
        return `<label ${cls === 'one' ? 'style="grid-column:1/-1"' : ''}>${t(lab)}${field}${bad ? `<span class="ferr">${esc(bad)}</span>` : ''}</label>`;
      }).join('')}</div></fieldset>`).join('') +
      (i.geom === 'parsel' && (cur.poly || []).length < 3 ? `<div class="note warn">${t('Gerçek parsel modu için Arazi ekranında sınır çizin.')}</div>` : '') +
      (i.grad && i.geom === 'parsel' ? `<p class="muted small">${t('Eğim yönü harita yükseklik verisinden alındı. Eğim alanlarını değiştirirseniz bu veri silinir.')}</p>` : '') +
      (val.warnings.length ? `<div class="note warn"><ul>${val.warnings.map(w => `<li>${esc(w)}</li>`).join('')}</ul></div>` : '') +
      `<p class="muted small">${t('Boş alanlarda gri değer varsayım olarak kullanılır ve raporda listelenir. Ondalık için virgül kullanabilirsiniz.')}</p>
       <div class="sticky"><button type="button" class="btn primary block" id="btnCalc" ${nErr ? 'disabled' : ''}>${t('Hesapla')}</button></div>`;
    $('#form').querySelectorAll('input,select').forEach(el => el.onchange = () => {
      const v = el.value.trim();
      if (v === '') delete i[el.name]; else i[el.name] = v;
      if (el.name === 'area_da') { delete i.L; delete i.W; }
      if (el.name === 'slopeLong' || el.name === 'slopeShort') delete i.grad;
      if (el.name === 'Ns' || el.name === 'crop') delete i.Ns;
      invalidateDesign(); persist(); renderForm();
    });
    $('#btnCalc').onclick = () => show('sonuc');
  }

  // ---------- Hesap ----------
  function compute() {
    const opt = designOpt();
    const r = E.design(cur.inp, settings, Object.assign({ manual: cur.shiftEdit || null }, opt));
    if (r.ok) { const before = cur.rev; St.snapshot(cur, 'hesap'); if (cur.rev !== before) save(KEY, projects); }
    if (r.ok && cur.shiftEdit && cur.shiftEdit.sig !== r.layout.sig) { delete cur.shiftEdit; persist(); }
    // Kayıtlı shift sayısı artık mümkün değilse (veriler değişti) seçimi sıfırla
    if (r.ok && cur.inp.Ns && !r.sectorAlts.some(a => a.Ns === Number(V.parseNum(cur.inp.Ns)))) { delete cur.inp.Ns; persist(); return compute(); }
    lastRes = r; overlayRes = r; return r;
  }
  const designOpt = () => ({ poly: cur.poly, src: cur.src, station: cur.station, route: cur.route, catalog });
  const PALETTE = ['#8fd19e', '#7cc5e8', '#f5c26b', '#e99aa8', '#b8a6e8', '#9fe0d3', '#d9d47a', '#f0a875', '#a3c2f0', '#c9e39a', '#e0b0d5', '#b5d99c'];
  function sectorIndex(r) { const m = []; r.sel.groups.forEach((gr, j) => gr.forEach(k => { m[k] = j; })); return m; }
  // Ana hat: kaynak → başlık → bant eksenleri boyunca en uzak alt ünite girişine
  function mainLines(r) {
    const Ly = r.layout, src = Ly.src, H = Ly.headerPts, segs = [];
    if (Ly.route) segs.push(Ly.route);
    segs.push([src, H[Ly.headerEntry]]);
    if (H.length > 1) segs.push(H);
    H.forEach(([ax, y]) => { const far = r.units.filter(u => u.ax === ax).reduce((m, u) => Math.abs(u.yIn - y) > Math.abs(m - y) ? u.yIn : m, y); if (far !== y) segs.push([[ax, y], [ax, far]]); });
    return segs;
  }


  // Shift kartları: alan, lateral/manifold sayısı, debi, giriş basıncı, süre, hacim, enerji, çalışan vanalar; içinde alt ünite ataması
  function shiftCards(r) {
    const sel = r.sel, m = r.main.sel, s = r.schedule, n = sel.groups.length;
    return sel.groups.map((gr, j) => {
      const A = gr.reduce((x, k) => x + r.units[k].Q, 0) / r.sectors.Qfield * r.field.da;
      const nLat = gr.reduce((x, k) => x + r.units[k].nLat, 0), V = sel.Qj[j] * s.t;
      const kWh = 9.81 * m.Hp[j] * (s.seasonM3 * sel.Qj[j] / r.sectors.Qfield) / 3600 / 0.63;
      const over = sel.Qj[j] > (V0(cur.inp.Q) || Infinity) + 1e-9;
      return `<details class="ucard"><summary><span class="dot" style="background:${PALETTE[j % PALETTE.length]}"></span><b>Shift ${j + 1}</b><span>${fmt(A, 1)} da</span><span class="${over ? 'bad' : ''}">${fmt(sel.Qj[j], 1)} m³/h${over ? ' ✗' : ''}</span><span>${fmt(m.H[j], 1)} m</span><span>${fmt(s.t, 1)} h</span></summary><div class="in"><div class="kv">
        <div>${t('Lateral sayısı')}</div><div>${fmt(nLat, 0)}</div><div>${t('Manifold sayısı')}</div><div>${gr.length}</div>
        <div>${t('Gerekli giriş basıncı')}</div><div>${fmt(m.H[j], 1)} m (${t('pompa')} ${fmt(m.Hp[j], 1)} m)</div>
        <div>${t('Su hacmi (bir sulama)')}</div><div>${fmt(V, 1)} m³</div><div>${t('Sezonluk enerji')}</div><div>${fmt(kWh, 0)} kWh</div>
        <div>${t('Açılacak manifoldlar')}</div><div>${gr.map(k => 'M' + (k + 1)).join(', ')}</div></div>
        <div class="scroll"><table><tr><th>${t('Alt ünite')}</th><th>${t('Debi')} m³/h</th><th>Lateral</th><th>Manifold</th><th>Shift</th></tr>${gr.map(k => { const u = r.units[k]; return `<tr><td>M${k + 1}</td><td>${fmt(u.Q, 2)}</td><td>${u.nLat}</td><td>Ø${u.pipe.od}</td><td><select data-unit="${k}">${Array.from({ length: n + 1 }, (_, q) => `<option value="${q}" ${q === j ? 'selected' : ''}>${q + 1}${q === n ? ' (' + t('yeni') + ')' : ''}</option>`).join('')}</select></td></tr>`; }).join('')}</table></div></div></details>`;
    }).join('');
  }
  const V0 = v => { const x = V.parseNum(v); return Number.isFinite(x) ? x : null; };
  const ROWD = { uzun: 'Uzun kenara paralel', kisa: 'Kısa kenara paralel' };
  function altHtml(A) {
    const P = A.picks, tagOf = v => [[P.yatirim, A.priced ? 'En düşük yatırım' : 'En az boru metrajı'], [P.enerji, 'En düşük enerji'], [P.dengeli, 'Dengeli']].filter(([x]) => x === v).map(([, l]) => `<span class="tag">${t(l)}</span>`).join(' ');
    return `${A.priced ? '' : `<div class="note warn small">${t('Bazı kalemlerin fiyatı eksik: yatırım karşılaştırması boru metrajıyla yapıldı, ekonomik sıralama kesin değildir.')}</div>`}
      <div class="scroll"><table><tr><th>${t('Sıra yönü')}</th><th>Lateral</th><th>Shift</th><th>${t('Boru')} m</th><th>${t('Motor')} kW</th><th>${t('Enerji')} kWh/${t('yıl')}</th><th>${t('Yatırım')} ₺</th><th>5 / 10 / 15 ${t('yıl')} ₺</th></tr>
      ${A.list.map((v, i) => v.ok ? `<tr class="click ${String(cur.inp.rowDir || 'uzun') === v.rowDir && String(cur.inp.latD || '') === v.latD ? 'sel' : ''}" data-alt="${i}"><td>${t(ROWD[v.rowDir])}${tagOf(v) ? '<br>' + tagOf(v) : ''}</td><td>Ø${v.latD}</td><td class="${v.feasible ? '' : 'bad'}">${v.Ns}${v.feasible ? '' : ' ✗'}</td><td>${fmt(v.pipeLen, 0)}</td><td>${v.motor ? fmt(v.motor, 1) : '—'}</td><td>${fmt(v.kWh, 0)}</td><td>${v.inv != null ? fmt(v.inv, 0) : `<span class="muted">${t('fiyat eksik')}</span>`}</td><td>${v.life ? v.life.map(x => fmt(x / 1000, 0)).join(' / ') + ' bin' : '—'}</td></tr>` : `<tr><td>${t(ROWD[v.rowDir])}</td><td>Ø${v.latD}</td><td colspan="6" class="bad small">${esc(v.err)}</td></tr>`).join('')}</table></div>
      <p class="muted small">${t('Satıra dokunarak bu yerleşimi uygulayın (sıra yönü ve lateral çapı Veriler ekranına yazılır). ✗: tur süresi mevcut çalışma süresine sığmıyor.')}</p>`;
  }
  function bindAlt(el) {
    const b = $('#bAlt'); if (b) b.onclick = () => { b.disabled = true; b.textContent = t('Hesaplanıyor…'); setTimeout(() => safely(() => { altCache = E.layoutAlternatives(cur.inp, settings, designOpt()); $('#altBody').innerHTML = altHtml(altCache); bindAlt(el); }, t('Alternatifler')), 30); };
    el.querySelectorAll('tr[data-alt]').forEach(x => x.onclick = () => { const v = altCache.list[+x.dataset.alt]; const keep = altCache; cur.inp.rowDir = v.rowDir; cur.inp.latD = v.latD; delete cur.inp.Ns; delete cur.inp.mainOd; delete cur.shiftEdit; invalidateDesign(); altCache = keep; persist(); renderResult(); toast(t('Yerleşim uygulandı')); });
  }

  function renderResult() {
    const r = compute(), el = $('#result');
    const notes = (r.err.length ? `<div class="note err"><b>${t('Kesin sonuç verilemiyor')}</b><ul>${r.err.map(e => `<li>${esc(e)}</li>`).join('')}</ul></div>` : '') +
      (r.warn.length ? `<div class="note warn"><b>${t('Uyarılar')}</b><ul>${r.warn.map(e => `<li>${esc(e)}</li>`).join('')}</ul></div>` : '') +
      (I.lang !== 'tr' && (r.warn.length || r.err.length) ? `<p class="muted small">${t('Hesap notları (uyarılar ve varsayımlar) şu an yalnız Türkçe gösterilir.')}</p>` : '');
    if (!r.ok) { el.innerHTML = notes + `<button class="btn block" id="bBack">${t('Verilere dön')}</button>`; $('#bBack').onclick = () => show('veri'); return; }
    const s = r.schedule, m = r.main.sel, sel = r.sel;
    el.innerHTML = `
    <div class="big">
      <div><b>${fmt(r.field.da, 1)} da</b><span>${esc(t(D.CROPS[cur.inp.crop].ad))} · ${r.field.mode === 'parsel' ? t('parsel') : t('dikdörtgen')}</span></div>
      <div><b>${r.sectors.Ns}</b><span>Shift · ${t('en büyük')} ${fmt(r.sectors.Qsec, 1)} m³/h</span></div>
      <div><b>${fmt(s.gross, 1)} ${t('mm/gün')}</b><span>${t('Tepe brüt su ihtiyacı')}</span></div>
      <div><b>${fmt(s.t, 1)} ${t('saat')}</b><span>${t('Shift başına / {n} günde bir', { n: s.interval })}</span></div>
    </div>
    ${notes}
    <div class="card"><h3>${t('Yerleşim planı')}</h3><div class="layout">${layoutSvg(r)}</div>
      <p class="muted small">${r.field.mode === 'parsel' ? t('Gerçek parsel sınırı üzerinde. Haritada görmek için Arazi ekranındaki “Plan” düğmesini kullanın.') : t('Eşdeğer dikdörtgen üzerinde. Gerçek sınır için Arazi ekranında parsel çizin ve “Uygula” deyin.')} ${t('Renkler shift’leri gösterir; lateraller seyreltilerek çizilmiştir.')}</p></div>
    <div class="card"><h3>${t('Shift planlaması alternatifleri')}</h3><p class="muted small">${t('Kaynak debisi')} ${fmt(cur.inp.Q ? V.parseNum(cur.inp.Q) : 0, 1)} m³/h. ${I.lang === 'tr' ? 'Öneri ölçütü: ' + esc(r.recBasis) + '. ' : ''}${t('Satıra dokunarak seçin.')}</p>
      <div class="scroll"><table><tr><th>Shift</th><th>${t('Maks. debi')} m³/h</th><th>${t('Tur')} h</th><th>${t('Ana hat')}</th><th>H m</th><th>${t('Motor')} kW</th><th>${t('Enerji')} kWh/${t('yıl')}</th><th>${t('Yıllık')} ₺</th></tr>
      ${r.sectorAlts.map(a => `<tr class="click ${a === sel ? 'sel' : ''}" data-ns="${a.Ns}"><td>${a.Ns}${a.recommended ? `<br><span class="tag">${t('Önerilen')}</span>` : ''}</td><td>${fmt(a.Qmax, 1)}</td><td class="${a.feasible ? '' : 'bad'}">${fmt(a.cycleHours, 1)}${a.feasible ? '' : ' ✗'}</td><td>Ø${a.main.sel.od}</td><td>${fmt(a.main.sel.Hmax, 1)}</td><td>${a.pump.need ? fmt(a.pump.motor, 1) : '—'}</td><td>${fmt(a.kWh, 0)}</td><td>${a.missing.length ? `<span class="muted">${t('fiyat eksik')}</span>` : fmt(a.compare, 0)}</td></tr>`).join('')}
      </table></div><p class="muted small">${t('Tur süresi, {d} günlük aralıkta mevcut {h} saatle karşılaştırılır (✗ sığmaz).', { d: s.interval, h: fmt(sel.avail, 0) })}</p></div>
    <div class="card"><h3>${t('Shift’ler')}${sel.manual ? ` <span class="tag warn">${t('elle düzenlendi')}</span>` : ''}</h3>${shiftCards(r)}
      <div class="row" style="margin-top:8px"><button class="btn sm" id="bShiftMap" style="flex:1">${t('Haritada düzenle')}</button>${sel.manual ? `<button class="btn sm" id="bShiftAuto" style="flex:1">${t('Otomatik')}</button>` : ''}</div>
      <p class="muted small">${t('Shift alanı, debi oranından hesaplanır.')} <a href="#" id="toHydro">${t('Hidrolik Hesap Tablosu')} →</a></p></div>
    <div class="card"><h3>${t('Hidrolik')}</h3><div class="kv">
      <div>Lateral</div><div>Ø${r.lateral.d} · ${t('en uzun')} ${fmt(r.lateral.maxLen, 1)} m (${t('izin')} ${fmt(r.lateral.Lmax, 1)} m)</div>
      <div>${t('Lateral adedi / toplam')}</div><div>${fmt(r.lateral.count, 0)} · ${fmt(r.lateral.len, 0)} m</div>
      ${r.lateral.lead > 1 ? `<div>${t('Kör lateral')}</div><div>${fmt(r.lateral.lead, 0)} m</div>` : ''}
      <div>${t('Lateral basınç farkı')}</div><div>${fmt(r.lateral.maxDH, 2)} / ${fmt(r.emitter.allowLat, 2)} m</div>
      <div>${t('Alt ünite (manifold)')}</div><div>${r.manifold.count} · ${r.manifold.byPipe.map(b => `Ø${b.pipe.od} PN${b.pipe.pn} ×${b.count}`).join(', ')}</div>
      <div>${t('Manifold maks. debi / hız')}</div><div>${fmt(r.manifold.Qmax, 1)} m³/h · ${fmt(r.manifold.vMax, 2)} m/s</div>
      <div>${t('Manifold basınç farkı')}</div><div>${fmt(r.manifold.varMax, 2)} / ${fmt(r.emitter.allowMan, 2)} m</div>
      <div>${t('Lateral / manifold giriş')}</div><div>${fmt(r.inlet.hLatIn, 1)} / ${fmt(r.inlet.hManIn, 1)} m</div>
      <div>${t('Ana hat')}</div><div>PVC Ø${m.od} PN${m.pn} · ${fmt(r.main.Lmain, 0)} m</div>
      ${r.layout.route ? `<div>${t('Çizilen güzergâh')}</div><div>${fmt(r.layout.routeLen, 0)} m</div>` : ''}
      <div>${t('Ana hat hız / kayıp')}</div><div>${fmt(m.v, 2)} m/s · ${fmt(m.hf, 1)} m</div>
      <div>${t('Filtre / vana kaybı')}</div><div>${fmt(r.head.filter, 1)} / ${fmt(r.head.valve, 1)} m</div>
      <div>${t('Gerekli basma yüksekliği')}</div><div>${fmt(m.Hmax, 1)} mSS</div>
    </div></div>
    <div class="card"><h3>${t('Ekipman')}</h3><div class="kv">
      <div>${t('Pompa')}</div><div style="text-align:end">${esc(r.pump.need ? (r.pump.fromCatalog ? `${r.pump.ad}, ${fmt(r.pump.motor, 1)} kW — ${fmt(r.pump.Q, 1)} m³/h @ ${fmt(r.pump.H, 1)} m` : `${t('Katalogda uygun pompa yok')} — ${fmt(r.pump.Q, 1)} m³/h @ ${fmt(r.pump.H, 1)} m, ~${fmt(r.pump.motor, 1)} kW`) : t('Pompa gerekmez'))}${r.pump.fromCatalog && !r.pump.verified ? `<br><span class="tag warn">${t('doğrulanmamış katalog')}</span>` : ''}</div>
      ${r.pump.fromCatalog ? `<div>${t('Çalışma noktaları')}</div><div style="text-align:end">${r.pump.pts.map(x => `${fmt(x.Q, 1)} m³/h: ${fmt(x.H, 1)} m (${t('gerekli')} ${fmt(x.Hreq, 1)}), η %${fmt(x.eta, 0)}`).join('<br>')}</div>` : ''}
      <div>${t('Filtrasyon')}</div><div style="text-align:end">${esc(r.filter.items.map(({ f, n }) => `${n} × ${t(f.ad)}`).join(' + ') || '—')}</div>
      <div>${t('Shift vanası')}</div><div>${esc(r.valve.v ? r.valve.v.cap : '—')} × ${r.sectors.Ns}</div>
    </div><p class="muted small">${t('Pompa, her shift debisinde eğrisi gerekli basıncı karşılayan ve sezonluk enerjisi en düşük katalog kaydıdır. Jenerik kayıtlar gerçek ürün değildir; gerçek kataloğu ⚙ Ayarlar\'dan yükleyin.')}</p></div>
    <div class="card"><h3>${t('Ana hat alternatifleri')} (${sel.Ns} shift)</h3><p class="muted small">${r.main.allPriced ? t('Yıllık = boru yatırımının {n} yıllık taksiti + enerji.', { n: settings.omur }) : t('Bazı çapların fiyatı yok: çap hız ölçütüyle seçildi.')} ${t('Satıra dokunarak seçin.')}</p>
      <div class="scroll"><table><tr><th>${t('Çap')}</th><th>${t('Hız')}</th><th>${t('Kayıp')} m</th><th>H m</th><th>${t('Boru')} ₺</th><th>${t('Enerji')} ₺/${t('yıl')}</th><th>${t('Yıllık')} ₺</th></tr>
      ${r.main.alts.map(a => `<tr class="click ${a === m ? 'sel' : ''}" data-od="${a.od}"><td>Ø${a.od} PN${a.pn}${a.tags.map(x => `<br><span class="tag">${t(x)}</span>`).join('')}</td><td>${fmt(a.v, 2)}</td><td>${fmt(a.hf, 1)}</td><td>${fmt(a.Hmax, 1)}</td><td>${a.pipeCost != null ? fmt(a.pipeCost, 0) : '—'}</td><td>${fmt(a.energyCost, 0)}</td><td><b>${a.annual != null ? fmt(a.annual, 0) : '—'}</b></td></tr>`).join('')}
      </table></div></div>
    <div class="card" id="altCard"><h3>${t('Yerleşim alternatifleri')}</h3><div id="altBody">${altCache ? altHtml(altCache) : `<p class="muted small">${t('Sıra yönü ve lateral çapının 4 birleşimi tam tasarımla hesaplanır; en düşük yatırım, en düşük enerji ve dengeli seçenek işaretlenir.')}</p><button class="btn sm" id="bAlt">${t('Alternatifleri hesapla')}</button>`}</div></div>
    <div class="card"><h3>${t('Sulama programı')}</h3><div class="kv">
      <div>ET0 (${t('tepe')})</div><div>${fmt(s.et0, 2)} ${t('mm/gün')}</div><div>Kc · Kr</div><div>${fmt(s.kc, 2)} · ${fmt(s.Kr, 2)}</div>
      <div>${t('Net / brüt ihtiyaç')}</div><div>${fmt(s.net, 2)} / ${fmt(s.gross, 2)} ${t('mm/gün')}</div>
      <div>${t('Bitki başına (tepe)')}</div><div>${fmt(s.lpPlant, 1)} ${t('l/gün')}</div>
      <div>${t('Uygulama hızı')}</div><div>${fmt(s.AR, 2)} mm/h</div><div>${t('Maks. aralık (toprak)')}</div><div>${s.Imax} ${t('gün')}</div>
      <div>${t('Bir tur (tüm shift’ler)')}</div><div>${fmt(s.cycleHours, 1)} ${t('saat')}</div>
      <div>${t('Sezonluk su')}</div><div>${fmt(s.seasonM3, 0)} m³ (${fmt(s.seasonM3 / r.field.da, 0)} m³/da)</div>
      <div>${t('Sezonluk enerji')}</div><div>${fmt(s.kWh, 0)} kWh · ${tl(s.energyCost)}${s.epSrc === 'ornek' ? ' (' + t('örnek fiyat') + ')' : ''}</div>
    </div>
    <div class="scroll" style="margin-top:10px"><table><tr><th>${t('Ay')}</th><th>Kc</th><th>ET0</th><th>${t('Brüt')} mm</th><th>${t('Aralık')}</th><th>${t('Süre')} h</th><th>m³/da</th></tr>
      ${s.monthly.map(x => `<tr><td>${monthName(x.m)}</td><td>${fmt(x.kc, 2)}</td><td>${fmt(x.et0, 1)}</td><td>${fmt(x.gross, 1)}</td><td>${x.interval}</td><td>${fmt(x.sure, 1)}</td><td>${fmt(x.m3da, 0)}</td></tr>`).join('')}</table></div></div>
    <div class="card"><details><summary>${t('Varsayımlar')} (${r.asm.length})</summary><ul class="small">${r.asm.map(a => `<li>${esc(a)}</li>`).join('')}</ul></details></div>
    <div class="row"><button class="btn primary" style="flex:1" id="bPdf">${t('PDF rapor')}</button><button class="btn" style="flex:1" id="bXls">Excel</button></div>`;
    el.querySelectorAll('tr[data-ns]').forEach(x => x.onclick = () => { const k = Number(x.dataset.ns); if (r.sectorAlts.find(a => a.recommended).Ns === k) delete cur.inp.Ns; else cur.inp.Ns = k; delete cur.inp.mainOd; persist(); renderResult(); });
    el.querySelectorAll('tr[data-od]').forEach(x => x.onclick = () => { cur.inp.mainOd = Number(x.dataset.od); persist(); renderResult(); });
    bindAlt(el);
    el.querySelectorAll('select[data-unit]').forEach(x => x.onchange = () => {
      const assign = sectorIndex(r).slice(); assign[+x.dataset.unit] = +x.value;
      const ids = [...new Set(assign)].sort((p, q) => p - q), mp = new Map(ids.map((v, i) => [v, i]));
      cur.shiftEdit = { sig: r.layout.sig, assign: assign.map(v => mp.get(v)) }; invalidateDesign(); persist(); renderResult();
    });
    $('#bShiftMap').onclick = () => { if (r.layout.mode !== 'parsel') return toast(t('Harita planı için önce “Uygula” deyin (gerçek parsel modu)')); show('arazi'); setMode('shift'); drawPoly(); };
    const sa = $('#bShiftAuto'); if (sa) sa.onclick = () => { delete cur.shiftEdit; invalidateDesign(); persist(); renderResult(); };
    $('#toHydro').onclick = e => { e.preventDefault(); show('hidrolik'); };
    bindExport('#bPdf', '#bXls', r);
  }
  const monthName = m => new Date(2026, m - 1, 1).toLocaleDateString(I.locale, { month: 'short' });
  function bindExport(a, b, r) {
    const run = (btn, label, fn) => { const el = $(btn); el.onclick = async () => { if (el.disabled) return; el.disabled = true; const old = el.textContent; el.textContent = t('{x} hazırlanıyor…', { x: label }); try { await fn(); } catch (e) { toast(t('{x} hatası: ', { x: label }) + (e && e.message || e)); } finally { el.disabled = false; el.textContent = old; } }; };
    run(a, 'PDF', () => window.IrriReport.pdf(cur, r, layoutSvg(r)));
    run(b, 'Excel', () => window.IrriReport.xlsx(cur, r));
  }

  // Yerleşim planı (SVG, çerçeve koordinatları; y yukarı)
  function layoutSvg(r) {
    const Ly = r.layout, P = Ly.P, src = Ly.src;
    const RT = Ly.route || [src];
    const xs = P.map(p => p[0]).concat(RT.map(p => p[0])), ys = P.map(p => p[1]).concat(RT.map(p => p[1]));
    const ex0 = Math.min(...xs), ex1 = Math.max(...xs), ey0 = Math.min(...ys), ey1 = Math.max(...ys);
    const VW = 680, pad = 36, sc = Math.min((VW - 2 * pad) / Math.max(ex1 - ex0, 1), 440 / Math.max(ey1 - ey0, 1));
    const VH = (ey1 - ey0) * sc + 2 * pad + 30;
    const X = x => (pad + (x - ex0) * sc).toFixed(1), Y = y => (pad + (ey1 - y) * sc).toFixed(1);
    const path = pts => 'M' + pts.map(p => X(p[0]) + ',' + Y(p[1])).join('L') + 'Z';
    const secOf = sectorIndex(r);
    let s = `<svg viewBox="0 0 ${VW} ${VH.toFixed(0)}" xmlns="http://www.w3.org/2000/svg" font-family="DejaVu Sans, sans-serif"><rect width="${VW}" height="${VH.toFixed(0)}" fill="#f7faf8"/>`;
    s += `<path d="${path(P)}" fill="#eef3ef"/>`;
    r.units.forEach((u, k) => { const b = Ly.bands[u.band], c = Gm.clipRect(P, b.x0, b.x1, u.y0, u.y1); if (c.length >= 3) s += `<path d="${path(c)}" fill="${PALETTE[secOf[k] % PALETTE.length]}" stroke="#fff" stroke-width="1"/>`; });
    const step = Math.max(1, Math.ceil(Ly.laterals.length / 500));
    for (let i = 0; i < Ly.laterals.length; i += step) { const l = Ly.laterals[i]; s += `<line x1="${X(l.ax)}" y1="${Y(l.y)}" x2="${X(l.ax + l.side * l.len)}" y2="${Y(l.y)}" stroke="#2e7d4f" stroke-width=".5" opacity=".75"/>`; }
    r.units.forEach(u => { s += `<line x1="${X(u.ax)}" y1="${Y(u.yIn)}" x2="${X(u.ax)}" y2="${Y(u.yEnd)}" stroke="#1565c0" stroke-width="2.2"/>`; });
    mainLines(r).forEach(seg => { s += `<polyline points="${seg.map(p => X(p[0]) + ',' + Y(p[1])).join(' ')}" fill="none" stroke="#c62828" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>`; });
    r.units.forEach((u, k) => { const cx = +X(u.ax), cy = (+Y(u.yIn) + +Y(u.yEnd)) / 2; if (Math.abs(u.yEnd - u.yIn) * sc > 16) s += `<text x="${cx + 4}" y="${cy + 4}" font-size="10" fill="#15231c">S${secOf[k] + 1}</text>`; });
    s += `<path d="${path(P)}" fill="none" stroke="#15231c" stroke-width="1.3"/>`;
    const s0 = RT[0];
    s += `<circle cx="${X(s0[0])}" cy="${Y(s0[1])}" r="6" fill="#00bcd4" stroke="#fff"/><text x="${+X(s0[0]) + 8}" y="${+Y(s0[1]) - 6}" font-size="10" fill="#007c8c">${t('Kaynak')}</text>`;
    // ölçek çubuğu
    const target = (ex1 - ex0) / 5, nice = [5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000].find(v => v >= target) || 5000, bx = pad, by = VH - 14;
    s += `<g font-size="10" fill="#15231c"><line x1="${bx}" y1="${by}" x2="${bx + nice * sc}" y2="${by}" stroke="#15231c" stroke-width="2"/><line x1="${bx}" y1="${by - 4}" x2="${bx}" y2="${by + 2}" stroke="#15231c"/><line x1="${bx + nice * sc}" y1="${by - 4}" x2="${bx + nice * sc}" y2="${by + 2}" stroke="#15231c"/><text x="${bx + nice * sc + 6}" y="${by + 4}">${nice} m</text></g>`;
    // kuzey oku (yalnız parsel modunda gerçek yön)
    if (Ly.mode === 'parsel') { const [nx, ny] = Gm.rot([0, 1], Ly.angle), cx = VW - 26, cy = 26; s += `<g><line x1="${cx - nx * 12}" y1="${cy + ny * 12}" x2="${cx + nx * 12}" y2="${cy - ny * 12}" stroke="#15231c" stroke-width="2" marker-end="url(#ar)"/><text x="${cx + nx * 20 - 4}" y="${cy - ny * 20 + 4}" font-size="11" font-weight="bold">${t('K')}</text></g><defs><marker id="ar" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto"><path d="M0,0L6,3L0,6Z" fill="#15231c"/></marker></defs>`; }
    const lx = VW - 300, ly = VH - 10;
    s += `<g font-size="10" fill="#15231c"><line x1="${lx}" x2="${lx + 16}" y1="${ly - 3}" y2="${ly - 3}" stroke="#c62828" stroke-width="3"/><text x="${lx + 20}" y="${ly}">${t('Ana hat')} Ø${r.main.sel.od}</text>
      <line x1="${lx + 105}" x2="${lx + 121}" y1="${ly - 3}" y2="${ly - 3}" stroke="#1565c0" stroke-width="2"/><text x="${lx + 125}" y="${ly}">Manifold</text>
      <line x1="${lx + 185}" x2="${lx + 201}" y1="${ly - 3}" y2="${ly - 3}" stroke="#2e7d4f"/><text x="${lx + 205}" y="${ly}">Lateral Ø${r.lateral.d}</text></g>`;
    return s + '</svg>';
  }

  // ---------- Malzeme ----------
  function renderBom() {
    const r = lastRes && lastRes.ok ? lastRes : compute();
    if (!r.ok) { $('#bom').innerHTML = `<div class="note err">${t('Malzeme listesi için önce hesaplamanın tamamlanması gerekir. Sonuç ekranındaki eksikleri giderin.')}</div>`; return; }
    const priced = r.bom.filter(b => b.fiyat != null), unpriced = r.bom.filter(b => b.fiyat == null);
    const row = (x, withPrice) => `<tr><td>${esc(x.kalem)}${x.opsiyonel ? ` <span class="muted small">(${t('opsiyonel')})</span>` : ''}<br><span class="muted small">${esc(t(x.grup))}</span></td><td>${fmt(x.miktar, 0)} ${t(x.birim)}</td>
      <td><input class="price" data-key="${esc(x.key)}" type="text" inputmode="decimal" value="${x.fiyat != null && x.kaynak === 'kullanici' ? String(x.fiyat).replace('.', ',') : ''}" placeholder="${x.fiyat != null ? fmt(x.fiyat, 2) : t('fiyat')}">${withPrice && x.kaynak !== 'kullanici' ? `<span class="tag ${x.kaynak === 'ornek' ? 'warn' : ''}">${SRC()[x.kaynak]}</span>` : ''}</td><td>${x.tutar != null ? fmt(x.tutar, 0) : '—'}</td></tr>`;
    const c = r.cost, head = `<tr><th>${t('Kalem')}</th><th>${t('Miktar')}</th><th>${t('Birim')} ₺</th><th>${t('Tutar')}</th></tr>`;
    $('#bom').innerHTML = `
      <div class="card"><h3>${t('Maliyet')}</h3>
        ${c.total != null ? `<div class="big"><div style="grid-column:1/-1"><b>${tl(c.total)}</b><span>${t('Toplam malzeme bedeli')}${c.example ? ' · ' + t('{n} kalem örnek fiyatlı', { n: c.example }) : ''}</span></div></div>`
        : `<div class="note err"><b>${t('Toplam proje maliyeti hesaplanmadı:')}</b> ${t('{n} zorunlu kalemin fiyatı eksik. Fiyatları aşağıdaki listeye girin.', { n: c.missing })}</div>
           <div class="kv"><div>${t('Fiyatlı kalemler ara toplamı')}</div><div>${tl(c.subtotal)}</div></div><p class="muted small">${t('Ara toplam eksik kalemleri içermez; proje bedeli olarak kullanılamaz.')}</p>`}
        ${c.example ? `<p class="muted small"><span class="tag warn">${t('örnek')}</span> ${t('işaretli fiyatlar uygulamanın varsayılan örnek değerleridir; güncel tedarikçi fiyatı girin.')}</p>` : ''}
      </div>
      ${unpriced.length ? `<div class="card"><h3>${t('Fiyatı eksik kalemler')} (${unpriced.length})</h3><div class="scroll"><table>${head}${unpriced.map(x => row(x, false)).join('')}</table></div></div>` : ''}
      <div class="card"><h3>${t('Fiyatlı kalemler')} (${priced.length})</h3><div class="scroll"><table>${head}${priced.map(x => row(x, true)).join('')}</table></div>
      <p class="muted small">${t('Miktarlara %2–3 fire payı eklidir. Girdiğiniz birim fiyatlar tüm projelerde kullanılır.')}</p></div>
      <div class="row"><button class="btn primary" style="flex:1" id="bPdf2">${t('PDF rapor')}</button><button class="btn" style="flex:1" id="bXls2">Excel</button></div>`;
    $('#bom').querySelectorAll('input.price').forEach(inp => inp.onchange = () => {
      const k = inp.dataset.key, v = V.parseNum(inp.value);
      if (inp.value.trim() === '') delete settings.items[k];
      else if (Number.isNaN(v) || v < 0) { toast(t('Geçerli, negatif olmayan bir fiyat girin')); inp.value = ''; return; }
      else settings.items[k] = v;
      saveSettings(); lastRes = null; renderBom();
    });
    bindExport('#bPdf2', '#bXls2', r);
  }

  // ---------- Hidrolik Hesap Tablosu (Excel SİSTEM + IRRIFRICT) ----------
  const SYS_ROWS = [
    ['crop', 'Bitki', '', 'txt'], ['area', 'Alan', 'da', 'in'], ['et', 'ET', 'mm/gün', 'in'], ['T', 'T', 'h', 'in'], ['Sr', 'Sıra Arası', 'm', 'in'], ['Sp', 'Sıra Üzeri', 'm', 'in'],
    ['nl', 'Lateral Sayısı', 'adet', 'in'], ['q', 'q', 'l/h', 'in'], ['Sd', 'Sd', 'm', 'in'], ['n', 'n', 'adet/bitki', 2], ['rate', 'Sulama hızı', 'mm/h', 2], ['Qp', 'Q bitki', 'l/h', 2],
    ['Tp', 'T bitki', 'h/gün', 2], ['maxShift', 'Max Shift (h)', 'adet', 0], ['shifts', 'Shift #', 'adet', 'in'], ['totalTime', 'Toplam Sulama Süresi', 'h', 1], ['totalQ', 'Toplam Debi', 'm³/h', 1],
    ['shiftQ', 'Shift Debi', 'm³/h', 1], ['target', 'Parsel Hedef Debi', 'm³/h', 'in'], ['parcels', 'Parsel Sayısı', 'adet', 0], ['parcelA', 'Ort. Parsel Alanı', 'da', 2], ['parcelQ', 'Ort. Parsel Debi', 'm³/h', 2],
    ['valves', 'Aynı Anda Çal. Vana', 'adet', 0], ['shiftMax', 'Shift Debi MAX', 'm³/h', 2], ['shiftMin', 'Shift Debi MIN', 'm³/h', 2],
  ];
  function hydroState() {
    cur.hydro = cur.hydro || {};
    const h = cur.hydro;
    h.fields = Array.isArray(h.fields) ? h.fields : []; while (h.fields.length < 6) h.fields.push({});
    h.fric = h.fric && typeof h.fric === 'object' ? h.fric : {};
    h.tab = h.tab || 'sys';
    return h;
  }
  let hydroSave = null;
  const persistSoon = () => { clearTimeout(hydroSave); hydroSave = setTimeout(persist, 400); };
  function renderHydro() {
    const h = hydroState(), el = $('#hydro');
    const r = lastRes && lastRes.ok ? lastRes : (cur.inp.Q ? compute() : null);
    el.innerHTML = `<div class="seg"><button data-tab="sys" class="${h.tab === 'sys' ? 'on' : ''}">${t('Sistem')} (SİSTEM)</button><button data-tab="fric" class="${h.tab === 'fric' ? 'on' : ''}">${t('Sürtünme')} (IRRIFRICT)</button></div>
      <div id="hBody"></div>
      <p class="muted small"><span class="cell-in legend"></span> ${t('Açık kahverengi: elle girilen değer')} · <span class="cell-out legend"></span> ${t('Beyaz: otomatik hesap')}. ${t('Formüller kullanıcının Excel dosyasından birebir alınmıştır.')}</p>
      <div class="row"><button class="btn primary" style="flex:1" id="hXls">${t('Excel (formüllü)')}</button></div>`;
    el.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { h.tab = b.dataset.tab; persist(); renderHydro(); });
    (h.tab === 'sys' ? renderSys : renderFric)(h, r);
    $('#hXls').onclick = async () => { const b = $('#hXls'); b.disabled = true; try { await window.IrriReport.hydroXlsx(cur); } catch (e) { toast(t('{x} hatası: ', { x: 'Excel' }) + e.message); } finally { b.disabled = false; } };
  }
  function renderSys(h, r) {
    const res = h.fields.map(f => HT.systemField(f));
    const cell = (k, j, kind) => {
      const f = h.fields[j], o = res[j];
      if (kind === 'txt' || kind === 'in') { const bad = kind === 'in' && o.bad.includes(k); return `<td class="cell-in ${bad ? 'badcell' : ''}"><input data-f="${j}" data-k="${k}" type="text" ${kind === 'in' ? 'inputmode="decimal"' : ''} value="${esc(inVal(f[k]))}"></td>`; }
      const v = o[k], red = k === 'totalTime' && o.overTime;
      return `<td class="cell-out ${red ? 'redcell' : ''}" id="s-${k}-${j}">${v == null ? '' : fmt(v, kind)}</td>`;
    };
    $('#hBody').innerHTML = `<div class="card"><div class="row wrap" style="justify-content:space-between"><h3 style="margin:0">${t('Arazi')}</h3>
      <div class="row">${r ? `<button class="btn sm" id="sysFill">${t('Field 1’i projeden doldur')}</button>` : ''}<button class="btn sm" id="sysClear">${t('Temizle')}</button></div></div>
      <div class="scroll xl"><table class="xltab"><tr><th>${t('Bölge')}</th>${h.fields.map((f, j) => `<th>Field ${j + 1}</th>`).join('')}<th></th></tr>
      ${SYS_ROWS.map(([k, lab, unit, kind]) => `<tr><th class="rl">${t(lab)}</th>${h.fields.map((f, j) => cell(k, j, kind)).join('')}<td class="unit">${t(unit)}</td></tr>`).join('')}
      </table></div>
      ${res.some(o => o.overTime) ? `<div class="note warn">${t('Kırmızı: toplam sulama süresi günlük çalışma süresini (T) aşıyor.')}</div>` : ''}
      ${r ? `<p class="muted small">${t('“Projeden doldur”: ET = projenin tepe brüt ihtiyacı, T = günlük çalışma, Shift # = seçili shift sayısı, hedef debi = en büyük alt ünite debisi.')}</p>` : ''}</div>`;
    $('#hBody').querySelectorAll('input[data-k]').forEach(inp => inp.oninput = () => {
      const j = +inp.dataset.f, k = inp.dataset.k, f = h.fields[j];
      if (inp.value.trim() === '') delete f[k]; else f[k] = inp.value.trim();
      const o = HT.systemField(f);
      SYS_ROWS.forEach(([kk, , , kind]) => { if (typeof kind === 'number') { const c = $(`#s-${kk}-${j}`); if (c) { c.textContent = o[kk] == null ? '' : fmt(o[kk], kind); c.classList.toggle('redcell', kk === 'totalTime' && o.overTime); } } });
      inp.parentElement.classList.toggle('badcell', o.bad.includes(k));
      persistSoon();
    });
    const fill = $('#sysFill'); if (fill) fill.onclick = () => { h.fields[0] = HT.fieldFromProject(cur, r, t(D.CROPS[cur.inp.crop].ad)); persist(); renderHydro(); };
    $('#sysClear').onclick = () => { if (confirm(t('SİSTEM tablosu temizlensin mi?'))) { h.fields = [{}, {}, {}, {}, {}, {}]; persist(); renderHydro(); } };
  }
  function renderFric(h, r) {
    const names = new Set(Object.keys(h.fric));
    if (r) for (let j = 1; j <= r.sectors.Ns; j++) names.add('Shift ' + j);
    if (!names.size) names.add('Shift 1');
    const list = [...names].sort((a, b) => (parseInt(a.replace(/\D/g, '')) || 0) - (parseInt(b.replace(/\D/g, '')) || 0));
    if (!h.sel || !list.includes(h.sel)) h.sel = list[0];
    const rows = h.fric[h.sel] = h.fric[h.sel] || [];
    const res = HT.friction(rows);
    const n = Math.min(15, Math.max(rows.length + 1, 2));
    const shiftIdx = parseInt(h.sel.replace(/\D/g, '')) - 1;
    const canFill = r && shiftIdx >= 0 && shiftIdx < r.sectors.Ns;
    const inp = (i, k, v, kind) => `<td class="cell-in"><input data-i="${i}" data-k="${k}" type="text" ${kind === 'num' ? 'inputmode="decimal"' : ''} value="${esc(inVal(v))}"></td>`;
    const sel = (i, k, v, opts) => `<td class="cell-in"><select data-i="${i}" data-k="${k}"><option value=""></option>${opts.map(o => `<option ${String(o) === String(v ?? '') ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select></td>`;
    const out = (v, d, cls = '') => `<td class="cell-out ${cls}">${v == null || v === '' ? '' : typeof v === 'number' ? fmt(v, d) : esc(v)}</td>`;
    $('#hBody').innerHTML = `<div class="card"><div class="chips">${list.map(x => `<button class="chip ${x === h.sel ? 'on' : ''}" data-s="${esc(x)}">${esc(x)}</button>`).join('')}<button class="chip" id="fAdd">＋</button></div>
      <div class="row wrap" style="margin:8px 0">${canFill ? `<button class="btn sm" id="fFill">${t('Bu shift’i projeden doldur')}</button>` : ''}<button class="btn sm" id="fCopy">${t('Kopyala')}</button><button class="btn sm danger" id="fDel">${t('Temizle')}</button></div>
      <div class="scroll xl"><table class="xltab fr"><tr><th>#</th><th>${t('Tip')}</th><th>${t('Malzeme')}</th><th>PN</th><th>${t('Uzunluk')}, m</th><th>${t('Debi')}, m³/h</th><th>${t('Başlangıç kotu')}, m</th><th>${t('Bitiş kotu')}, m</th><th>${t('Vana min. basınç')}, mSS</th><th>${t('Eğim')}, %</th><th>ID, mm</th><th>C</th><th>${t('Sürtünme')}, m/m</th><th>${t('Sürtünme toplam')}, m</th><th>${t('Kot farkı')}, m</th><th>${t('Toplam kayıp')}, mSS</th><th>${t('Çap/basınç kontrol')}</th><th>${t('Hız')}, m/s</th><th>${t('Hız kontrol')}</th></tr>
      ${res.rows.slice(0, n).map((o, i) => { const rw = rows[i] || {}; return `<tr><th>${i + 1}</th>${sel(i, 'type', rw.type, HT.TYPES)}${sel(i, 'material', rw.material, HT.MATERIALS)}${sel(i, 'pn', rw.pn, rw.material ? HT.pnsOf(rw.material) : [])}${inp(i, 'L', rw.L, 'num')}${inp(i, 'Q', rw.Q, 'num')}${inp(i, 'h1', rw.h1, 'num')}${i === 0 ? inp(i, 'h2', rw.h2, 'num') : out(o.I, 2, 'grey')}${i === 0 ? inp(i, 'pmin', rw.pmin, 'num') : out(o.J, 2, 'grey')}${out(o.K, 2)}${out(o.L, 1)}${out(o.M, 0)}${out(o.N, 4)}${out(o.O, 2)}${out(o.P, 2)}${out(o.Qc, 2)}${out(o.R ? t(o.R) : '', 0, o.R === 'DN, PN control' ? 'redcell' : '')}${out(o.S, 2)}${out(o.T ? t(o.T) : '', 0, o.T === 'V control' ? 'redcell' : '')}</tr>`; }).join('')}
      </table></div>
      <div class="kv" style="margin-top:10px"><div>${t('Toplam sürtünme kaybı')}</div><div>${fmt(res.totalLoss, 2)} m</div><div>${t('Toplam kot farkı')}</div><div>${fmt(res.totalDz, 2)} m</div><div>${t('Gerekli giriş basıncı')}</div><div><b>${res.required == null ? '—' : fmt(res.required, 2) + ' mSS (' + fmt(res.required / 10.2, 2) + ' bar)'}</b></div></div>
      ${res.warnings.length ? `<div class="note warn">${t('Kütüphanede bulunmayan malzeme/PN: satır {n}', { n: res.warnings.map(i => i + 1).join(', ') })}</div>` : ''}
      <p class="muted small">${t('Satırlar akış yönünün tersine sıralanır: 1. satır en uç (vana) segmentidir; her satırın gerekli basıncı bir öncekinin basıncı + kaybıdır. Submain satırında Christiansen F = 0,354 (200’den fazla çıkış) uygulanır.')}</p></div>`;
    const body = $('#hBody');
    body.querySelectorAll('[data-s]').forEach(b => b.onclick = () => { h.sel = b.dataset.s; persist(); renderHydro(); });
    $('#fAdd').onclick = () => { let k = list.length + 1; while (names.has('Shift ' + k)) k++; h.sel = 'Shift ' + k; h.fric[h.sel] = []; persist(); renderHydro(); };
    body.querySelectorAll('[data-i]').forEach(c => c.onchange = () => {
      const i = +c.dataset.i, k = c.dataset.k; rows[i] = rows[i] || {};
      if (c.value === '') delete rows[i][k]; else rows[i][k] = c.value;
      if (k === 'material') { const p = HT.pnsOf(c.value); if (!p.map(String).includes(String(rows[i].pn))) rows[i].pn = p.includes(6) ? 6 : p[0]; }
      while (rows.length && !Object.keys(rows[rows.length - 1] || {}).length) rows.pop();
      persist(); renderHydro();
    });
    const fill = $('#fFill'); if (fill) fill.onclick = () => { h.fric[h.sel] = HT.segmentsFromShift(r, shiftIdx); persist(); renderHydro(); };
    $('#fCopy').onclick = () => { let k = list.length + 1; while (names.has('Shift ' + k)) k++; const nm = 'Shift ' + k; h.fric[nm] = JSON.parse(JSON.stringify(rows)); h.sel = nm; persist(); renderHydro(); };
    $('#fDel').onclick = () => { if (confirm(t('{s} tablosu temizlensin mi?', { s: h.sel }))) { delete h.fric[h.sel]; persist(); renderHydro(); } };
  }

  // ---------- Ayarlar ----------
  function langSelect(id) { return `<select id="${id}">${Object.entries(I.LANGS).map(([k, v]) => `<option value="${k}" ${k === I.lang ? 'selected' : ''}>${v.ad}</option>`).join('')}</select>`; }
  function bindLang(id) { const s = $('#' + id); if (s) s.onchange = () => { I.setLang(s.value); lastRes = null; $('#projName').textContent = cur ? cur.name : t('Proje seçilmedi'); const v = document.querySelector('nav.tabs button.on'); show(document.querySelector('.view.on').id.slice(2) || (v && v.dataset.v) || 'projeler'); }; }
  function renderSettings() {
    const s = settings, inp = (k, v, lab) => `<label>${lab}<input data-k="${k}" type="text" inputmode="decimal" value="${String(v ?? '').replace('.', ',')}">${s.edited[k] ? '' : `<span class="muted small">${t('örnek değer')}</span>`}</label>`;
    const cnt = (a, f) => t('{n} kayıt ({m} doğrulanmış)', { n: a.length, m: a.filter(f || (x => x.dogrulandi)).length });
    $('#settings').innerHTML = `<div class="card"><h3>${t('Dil')} / Language</h3>${langSelect('langSet')}
      ${['he', 'zh'].includes(I.lang) ? `<p class="muted small">${t('PDF raporu bu dilde İngilizce üretilir (yazı tipi ve yazım yönü kısıtı); Excel raporu seçili dildedir.')}</p>` : ''}</div>
      <div class="card"><h3>${t('Birim fiyatlar')} (₺)</h3><p class="muted small">${t('Varsayılanlar yalnızca örnektir. Diğer kalemlerin fiyatları Malzeme ekranından girilir.')}</p>
      <div class="f">${inp('lateral16', s.lateral16, t('Damla borusu') + ' Ø16 (₺/m)')}${inp('lateral20', s.lateral20, t('Damla borusu') + ' Ø20 (₺/m)')}${inp('damlatici', s.damlatici, t('Damlatıcı') + ' (₺/' + t('adet') + ')')}${inp('startKonnektor', s.startKonnektor, t('Start konnektör') + ' (₺)')}${inp('laterlSonu', s.laterlSonu, t('Lateral sonu') + ' (₺)')}${inp('elektrik', s.elektrik, t('Elektrik') + ' (₺/kWh)')}${inp('faiz', s.faiz, t('Faiz oranı (0,10 = %10)'))}${inp('omur', s.omur, t('Ekonomik ömür (yıl)'))}</div>
      <h3 style="margin-top:14px">${t('PE manifold')} PN6 (₺/m)</h3><div class="f">${Object.entries(s.pe).map(([d, v]) => inp('pe.' + d, v, 'Ø' + d)).join('')}</div>
      <h3 style="margin-top:14px">${t('PVC ana hat')} PN6 (₺/m)</h3><div class="f">${Object.entries(s.pvc).map(([d, v]) => inp('pvc.' + d, v, 'Ø' + d)).join('')}</div>
      <p class="muted small">${t('PN10 fiyatı girilmezse PN6 fiyatının PE için 1,45, PVC için 1,5 katı (örnek) alınır.')}</p></div>
      <button class="btn block" id="bReset">${t('Varsayılan fiyatlara dön')}</button>
      <div class="card"><h3>${t('Ekipman kataloğu')}</h3><div class="kv">
        <div>${t('Pompa')}</div><div>${cnt(catalog.pompa)}</div><div>${t('Filtre')}</div><div>${cnt(catalog.filtre)}</div><div>${t('Vana')}</div><div>${cnt(catalog.vana)}</div>
        <div>PE / PVC / lateral</div><div>${catalog.borular.pe.length} / ${catalog.borular.pvc.length} / ${catalog.borular.lateral.length}</div>
        <div>${t('Kullanıcı kataloğu')}</div><div>${userCat ? esc(userCat.meta && userCat.meta.ad || t('yüklü')) : t('yok')}</div></div>
        <p class="muted small">${t('Varsayılan pompa/filtre/vana kayıtları jeneriktir (gerçek ürün değil). Üretici verilerini aynı JSON yapısında yükleyin; "dogrulandi": true kayıtlar raporda doğrulanmış görünür. "yalnizKullanici": {"pompa": true} jenerik pompaları devre dışı bırakır.')}</p>
        <div class="row wrap"><label class="btn sm" style="flex-direction:row">${t('Katalog yükle (JSON)')}<input type="file" id="catFile" accept=".json,application/json" style="display:none"></label>
        <button class="btn sm" id="catTpl">${t('Şablon indir')}</button>${userCat ? `<button class="btn sm danger" id="catDel">${t('Kullanıcı kataloğunu kaldır')}</button>` : ''}</div></div>
      <div class="card small muted"><b>IrriGrow v0.5.0</b><br>${t('Hesaplar: FAO-56, Keller & Bliesner, Watters-Keller, Hazen-Williams. Sonuçlar ön projelendirme içindir; uygulama projesi bir sulama mühendisince kontrol edilmelidir.')}</div>`;
    bindLang('langSet');
    $('#settings').querySelectorAll('input[data-k]').forEach(el => el.onchange = () => {
      const [a, b] = el.dataset.k.split('.'); const v = V.parseNum(el.value);
      if (v === null || Number.isNaN(v) || v < 0) { toast(t('Geçerli, negatif olmayan bir sayı girin')); renderSettings(); return; }
      if (a === 'omur' && v < 1) { toast(t('Ömür en az 1 yıl olmalı')); renderSettings(); return; }
      if (b) settings[a][b] = v; else settings[a] = v; settings.edited[el.dataset.k] = true; saveSettings(); renderSettings();
    });
    $('#bReset').onclick = () => { if (confirm(t('Fiyatlar (kalem fiyatları dahil) sıfırlansın mı?'))) { settings = Object.assign(JSON.parse(JSON.stringify(D.DEFAULT_PRICES)), { items: {}, edited: {} }); saveSettings(); renderSettings(); } };
    $('#catFile').onchange = async ev => {
      const f = ev.target.files[0]; if (!f) return;
      try {
        const j = JSON.parse(await f.text()); const e = Ct.checkCatalog(j);
        if (e.length) { alert(t('Katalog yüklenemedi:') + '\n' + e.slice(0, 12).join('\n') + (e.length > 12 ? `\n… +${e.length - 12}` : '')); return; }
        userCat = j; if (!save(CKEY, userCat)) return; catalog = Ct.mergeCatalog(window.IRRI_CATALOG, userCat); lastRes = null; toast(t('Katalog yüklendi')); renderSettings();
      } catch (err) { alert(t('JSON okunamadı: ') + err.message); }
    };
    $('#catTpl').onclick = () => window.IrriReport.json('irrigrow-katalog-sablon', {
      meta: { ad: 'Firma kataloğu', tarih: new Date().toISOString().slice(0, 10) }, yalnizKullanici: { pompa: false },
      pompa: [{ id: 'firma-model-1', marka: 'Marka', model: 'Model', tip: 'dalgic', motorKw: 15, fiyat: null, dogrulandi: true, kaynak: 'Katalog sayfa no', egri: [[0, 95, 0], [20, 88, 62], [35, 76, 72], [45, 64, 70], [55, 48, 60]] }],
      filtre: [{ id: 'firma-disk-3', tip: 'disk', ad: 'Disk filtre 3"', mesh: 120, qMax: 50, hTemiz: 2.5, kirlenme: 3, fiyat: null, dogrulandi: true }],
      vana: [{ id: 'firma-vana-3', tip: 'sektor', ad: 'Hidrolik vana 3"', cap: '3"', qMax: 50, kv: 110, fiyat: null, dogrulandi: true }],
      borular: { pe: [{ id: 'firma-pe-90-6', od: 90, pn: 6, ic: 83, fiyat: null }], pvc: [{ id: 'firma-pvc-110-6', od: 110, pn: 6, ic: 103.6, fiyat: null }], lateral: [{ id: 'lat16', od: 16, ic: 13.8, maxH: 25 }] },
    }).catch(e => toast(e.message));
    const del = $('#catDel'); if (del) del.onclick = () => { if (confirm(t('Kullanıcı kataloğu kaldırılsın mı?'))) { userCat = null; try { localStorage.removeItem(CKEY); } catch (e) { } catalog = window.IRRI_CATALOG; lastRes = null; renderSettings(); } };
  }

  window.IrriApp = { toast };
  window.addEventListener('error', e => toast(t('Hata: ') + (e.message || '?')));
  window.addEventListener('unhandledrejection', e => toast(t('Hata: ') + ((e.reason && e.reason.message) || '?')));
  I.apply();
  const hl = $('#heroLang'); if (hl) { hl.outerHTML = langSelect('heroLang'); bindLang('heroLang'); }
  $('#projName').textContent = t('Proje seçilmedi');
  show('projeler');
  setTimeout(() => { const s = $('#splash'); if (s) { s.classList.add('off'); setTimeout(() => s.remove(), 400); } }, 900);
})();
